# Habilidad: Ingeniero POS Nuevo Amanecer

Esta habilidad guía a Codex para auditar, estabilizar, corregir, probar y desarrollar el Sistema POS Nuevo Amanecer.

## Instalación en el repositorio

Copia la carpeta completa a:

```text
<raíz-del-repositorio>/.agents/skills/nuevo-amanecer-pos-engineer/
```

Codex detecta habilidades ubicadas en `.agents/skills` dentro del repositorio.

## Uso explícito

En Codex CLI o IDE:

```text
$ nuevo-amanecer-pos-engineer
```

También puedes usar `/skills` y seleccionar la habilidad.

## Uso implícito

Codex puede activarla automáticamente cuando la tarea mencione el Sistema POS Nuevo Amanecer, sus módulos, auditoría, responsive, códigos de barras, ventas, inventario, caja, tickets o Ishikawa.

## Auditoría estática auxiliar

```bash
python .agents/skills/nuevo-amanecer-pos-engineer/scripts/audit_pos_html.py index.html --format markdown --output auditoria.md
```

El script no sustituye pruebas de navegador ni revisión manual.
