# Auditoría, seguridad, estabilización e Ishikawa

## Cómo leer este documento

1. La primera parte define auditoría, clasificación, parches críticos y mejora del proceso.
2. La segunda parte es el manual técnico detallado de Ishikawa.
3. En caso de repetición entre ambas partes, prevalece la regla más segura y específica de `AGENTS.md`.

---

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ESTRATEGIA OBLIGATORIA: AUDITORÍA, ESTABILIZACIÓN E ISHIKAWA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El desarrollo del Sistema POS Nuevo Amanecer debe seguir dos etapas
obligatorias y consecutivas:

ETAPA 1: AUDITORÍA TÉCNICA Y ESTABILIZACIÓN INMEDIATA

Primero, ejecuta una auditoría técnica completa del sistema.

Durante esta etapa debes:

- Encontrar errores críticos.
- Encontrar vulnerabilidades y posibles exploits.
- Identificar riesgos de pérdida o corrupción de datos.
- Detectar funciones duplicadas o sobrescritas.
- Detectar IDs HTML duplicados.
- Detectar eventos que no se ejecutan o se ejecutan varias veces.
- Detectar validaciones que pueden ser evitadas.
- Detectar operaciones que puedan registrarse más de una vez.
- Detectar fallas en ventas, inventario, caja y pagos.
- Detectar configuraciones que no se guardan correctamente.
- Detectar datos que desaparecen al recargar.
- Detectar errores de almacenamiento.
- Detectar reglas CSS y responsive contradictorias.
- Detectar problemas exclusivos de teléfono o computadora.
- Detectar exposición innecesaria de datos sensibles.
- Detectar acciones críticas sin autorización.
- Detectar manipulaciones posibles desde la consola del navegador.
- Detectar importaciones de archivos peligrosas o mal validadas.
- Detectar mecanismos de respaldo y restauración inseguros.
- Detectar cualquier función que pueda borrar, duplicar o modificar información
  sin autorización.

Los errores y vulnerabilidades deben clasificarse según su gravedad:

1. Crítico.
2. Alto.
3. Medio.
4. Bajo.
5. Mejora preventiva.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PRIORIDAD DE CORRECCIÓN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Los problemas críticos y altos deben corregirse inmediatamente para estabilizar
el sistema.

No se necesita esperar la aprobación individual de cada corrección cuando exista
un riesgo inmediato de:

- Pérdida de productos.
- Pérdida de ventas.
- Pérdida de clientes.
- Pérdida de información de caja.
- Duplicación de cobros.
- Duplicación de ventas.
- Corrupción del inventario.
- Manipulación no autorizada.
- Borrado completo de datos.
- Ejecución de código malicioso.
- Inyección de contenido.
- Importación de archivos peligrosos.
- Exposición de información sensible.
- Anulación incorrecta de operaciones.
- Inconsistencia entre venta, caja e inventario.
- Bloqueo total de la aplicación.

Antes de aplicar un parche crítico:

1. Confirmar el archivo principal vigente.
2. Crear un respaldo o commit.
3. Reproducir el problema cuando sea posible.
4. Registrar la evidencia.
5. Identificar el alcance.
6. Aplicar el cambio mínimo necesario.
7. Probar la corrección.
8. Probar regresiones.
9. Documentar el resultado.

No deben realizarse rediseños visuales mientras se corrigen fallas críticas,
salvo que la propia interfaz sea la causa del riesgo.

No se deben agregar funciones nuevas durante la estabilización si no son
necesarias para resolver el problema.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
QUÉ SIGNIFICA “PARCHE INMEDIATO”
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Un parche inmediato es una corrección pequeña, controlada y verificable que
reduce o elimina un riesgo crítico sin alterar innecesariamente otras partes del
sistema.

Un parche inmediato puede:

- Añadir una validación obligatoria.
- Impedir operaciones duplicadas.
- Corregir un cálculo incorrecto.
- Corregir una condición peligrosa.
- Evitar que un producto se guarde dos veces.
- Evitar que una venta se confirme varias veces.
- Impedir que el botón Confirmar sea presionado repetidamente.
- Corregir un fallo en el guardado.
- Evitar que datos antiguos sobrescriban datos nuevos.
- Escapar contenido ingresado por el usuario.
- Validar archivos importados.
- Restringir acciones críticas.
- Corregir una función sobrescrita.
- Eliminar IDs duplicados.
- Restaurar la consistencia entre venta, caja e inventario.

Un parche inmediato no debe:

- Reescribir todo el proyecto.
- Cambiar el diseño general.
- Eliminar módulos.
- Borrar datos para ocultar el error.
- Desactivar validaciones.
- Crear una nueva arquitectura sin autorización.
- Cambiar reglas comerciales no relacionadas.
- Añadir varias funciones no solicitadas.
- Modificar módulos que no guardan relación con el problema.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SEGURIDAD Y EXPLOITS QUE DEBEN REVISARSE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

La auditoría debe revisar como mínimo los siguientes riesgos:

1. INYECCIÓN DE CONTENIDO

Revisar cualquier uso de:

- innerHTML.
- outerHTML.
- insertAdjacentHTML.
- document.write.
- Plantillas creadas con datos ingresados por usuarios.
- Nombres de productos.
- Nombres de clientes.
- Descripciones.
- Categorías personalizadas.
- Mensajes del ticket.
- Datos importados desde CSV, Excel o JSON.

Los datos de usuario no deben insertarse como HTML sin limpieza.

Preferir:

- textContent.
- createElement.
- setAttribute validado.
- Funciones de escape.
- Renderizado seguro.

2. DUPLICACIÓN DE OPERACIONES

Impedir:

- Doble clic en Confirmar venta.
- Dos ventas con el mismo identificador interno.
- Operaciones digitales repetidas.
- Dos movimientos de caja para una sola venta.
- Dos descuentos de inventario.
- Dos tickets con distinta información para la misma venta.
- Reintentos que vuelvan a ejecutar una operación ya confirmada.

Cada operación crítica debe tener:

- ID único.
- Estado de procesamiento.
- Bloqueo temporal del botón.
- Comprobación de duplicados.
- Resultado idempotente cuando corresponda.

3. CORRUPCIÓN DE DATOS

Revisar:

- Escrituras incompletas.
- Guardados parciales.
- Datos que se modifican antes de confirmar.
- Arrays compartidos por referencia.
- Restauraciones antiguas.
- Valores predeterminados que sobrescriben datos reales.
- Fallos entre inventario, caja y venta.
- Migraciones incompletas.
- Cierre del navegador durante una operación.

Las operaciones relacionadas deben ejecutarse como una unidad lógica:

- Crear venta.
- Descontar stock.
- Registrar caja.
- Guardar.
- Confirmar éxito.

Si una parte falla, el sistema debe detectar la inconsistencia y evitar dejar
datos parcialmente actualizados.

4. IMPORTACIÓN DE ARCHIVOS

Validar:

- Tipo de archivo.
- Tamaño.
- Estructura.
- Encabezados.
- Cantidad de filas.
- Valores obligatorios.
- Códigos duplicados.
- Fórmulas peligrosas en CSV.
- Texto ejecutable.
- Objetos JSON inesperados.
- Propiedades desconocidas.
- Valores extremadamente grandes.
- Fechas inválidas.
- Números negativos no permitidos.

No confiar en la extensión del archivo.

No ejecutar contenido importado.

No insertar texto importado directamente mediante innerHTML.

5. AUTORIZACIÓN Y CONTROL MAESTRO

Las acciones críticas deben requerir autorización:

- Borrar productos.
- Borrar ventas.
- Anular ventas.
- Modificar caja.
- Cerrar caja.
- Restaurar respaldo.
- Resetear sistema.
- Cambiar PIN.
- Desactivar seguridad.
- Importar datos que reemplazarán información existente.
- Modificar configuraciones críticas.

No considerar seguro un sistema únicamente porque el botón esté oculto.

La lógica también debe validar la autorización.

6. INFORMACIÓN SENSIBLE

No mostrar ni guardar innecesariamente:

- PIN en texto plano visible.
- Contraseñas.
- Tokens.
- Claves privadas.
- Datos bancarios completos.
- Información personal sin necesidad.
- Registros técnicos que expongan datos sensibles.

Debe reconocerse que un sistema HTML ejecutado completamente en el navegador no
puede proteger secretos con el mismo nivel que un servidor seguro.

No prometer seguridad absoluta cuando toda la lógica y los datos están en el
dispositivo del usuario.

7. ALMACENAMIENTO LOCAL

Revisar:

- Claves utilizadas.
- Datos duplicados.
- Cuota disponible.
- Errores de JSON.parse.
- Errores de JSON.stringify.
- Migraciones.
- Datos corruptos.
- Escrituras simultáneas.
- Recuperación después de una falla.
- Restauración de respaldo.
- Compatibilidad entre versiones.

Antes de realizar cambios destructivos, crear un respaldo recuperable.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RESULTADO OBLIGATORIO DE LA AUDITORÍA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

La auditoría debe entregar:

1. Resumen ejecutivo.
2. Archivo y versión analizados.
3. Errores críticos encontrados.
4. Vulnerabilidades encontradas.
5. Riesgos de pérdida de datos.
6. Errores funcionales.
7. Errores responsive.
8. Código duplicado.
9. Funciones sobrescritas.
10. Problemas de arquitectura.
11. Parches aplicados.
12. Archivos modificados.
13. Funciones modificadas.
14. Pruebas ejecutadas.
15. Problemas pendientes.
16. Riesgos que requieren una solución más profunda.

Para cada problema debe informarse:

- Identificador.
- Gravedad.
- Módulo.
- Descripción.
- Forma de reproducción.
- Causa encontrada.
- Riesgo.
- Corrección.
- Pruebas.
- Estado.

Estados permitidos:

- Corregido.
- Mitigado.
- Pendiente.
- Requiere información.
- Requiere rediseño.
- Requiere backend.
- No reproducido.
- Riesgo aceptado por el propietario.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ETAPA 2: ANÁLISIS ISHIKAWA Y MEJORA DEL PROCESO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Después de estabilizar los problemas críticos, analiza si existen patrones de
errores repetitivos.

No utilices Ishikawa únicamente para resolver el error actual.

Utilízalo también para identificar qué parte del proceso de desarrollo permite
que el mismo tipo de error vuelva a aparecer.

Se considera un patrón repetitivo cuando ocurre cualquiera de estas situaciones:

- El mismo botón falla en varias versiones.
- Aparecen varias funciones duplicadas.
- Las configuraciones vuelven a activarse después de cada cambio.
- Las correcciones se aplican sobre archivos antiguos.
- Los formularios Nuevo y Editar se comportan diferente.
- El diseño responsive se rompe repetidamente.
- Los datos desaparecen después de recargar.
- Una corrección vuelve a introducir un error anterior.
- Los eventos dinámicos dejan de funcionar.
- Las validaciones existen al guardar, pero no al editar.
- Se crean muchas versiones sin confirmar la causa raíz.
- El usuario reporta varias veces el mismo tipo de problema.
- Las pruebas manuales no detectan regresiones.
- Los errores nacen por copiar y pegar código.
- Varias funciones modifican el mismo estado.
- El archivo principal contiene reglas contradictorias.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EQUIPO DE ANÁLISIS ISHIKAWA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cuando se detecte un patrón repetitivo, reúne virtualmente al equipo técnico
del proyecto.

El análisis debe considerar las perspectivas de:

- Arquitecto de software.
- Programador JavaScript.
- Especialista HTML y DOM.
- Especialista CSS responsive.
- Especialista en almacenamiento.
- Especialista en seguridad.
- Diseñador UX/UI.
- Analista de puntos de venta.
- Ingeniero de control de calidad.
- Especialista en pruebas.
- Responsable de versiones.
- Representante del usuario del negocio.

Cada rol debe analizar el problema desde su especialidad.

No se debe simular una reunión decorativa.

Cada participante debe aportar:

- Una posible causa.
- Evidencia necesaria.
- Riesgo.
- Propuesta de prevención.
- Prueba que evitaría la repetición.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
OBJETIVO DEL ISHIKAWA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El propósito no es únicamente corregir el síntoma.

El propósito es cambiar el proceso, la arquitectura, las pruebas o las reglas de
desarrollo que permitieron que el defecto naciera.

Ejemplo:

Síntoma:

El botón “Añadir otro código de barras” vuelve a dejar de funcionar.

Corrección inmediata:

Reparar el evento y conservar la fila vacía.

Análisis Ishikawa:

Determinar por qué este tipo de error reaparece.

Posibles causas del proceso:

- La interfaz y el almacenamiento usan la misma función de normalización.
- Los elementos dinámicos pierden eventos al usar innerHTML.
- No existen pruebas automatizadas para códigos alternativos.
- Crear y Editar utilizan estructuras diferentes.
- Se modifica una versión anterior.
- No se prueba después de recargar.
- No se prueba en teléfono.
- No existe una fuente única del proyecto.
- El cambio se entrega sin revisar la consola.

Cambio preventivo:

- Separar estado temporal y datos guardados.
- Utilizar delegación de eventos.
- Unificar Crear y Editar.
- Agregar pruebas automáticas.
- Crear una sola fuente principal.
- Probar teléfono y computadora.
- Prohibir la entrega con errores de consola.
- Crear una lista obligatoria de regresión.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RAMAS DE ISHIKAWA PARA MEJORAR EL PROCESO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cuando el error sea repetitivo, analizar estas ramas:

1. ARQUITECTURA

- Código excesivamente acoplado.
- Archivo único demasiado grande.
- Estado global sin control.
- Varias fuentes de verdad.
- Funciones con demasiadas responsabilidades.
- Crear y Editar separados.
- Módulos que modifican directamente datos ajenos.
- Falta de capa de almacenamiento.
- Falta de contratos entre módulos.

2. MÉTODO DE DESARROLLO

- Cambios sin diagnóstico.
- Parches por intuición.
- Falta de reproducción.
- Falta de definición del resultado esperado.
- Cambios demasiado grandes.
- Modificaciones en módulos no relacionados.
- Correcciones realizadas sobre versiones antiguas.
- Copiar y pegar funciones.
- No documentar decisiones.

3. CONTROL DE VERSIONES

- Varios archivos principales.
- Nombres de versiones confusos.
- Cambios no integrados.
- Falta de commits.
- Falta de etiquetas estables.
- Diferencia entre archivo probado y entregado.
- Caché de versiones anteriores.
- Ausencia de historial claro.

4. PRUEBAS

- No existen pruebas automáticas.
- Solo se prueba el caso ideal.
- No se prueba recarga.
- No se prueba edición.
- No se prueba creación.
- No se prueba teléfono.
- No se prueba computadora.
- No se prueba con datos antiguos.
- No se revisa consola.
- No se ejecutan pruebas de regresión.

5. REQUISITOS

- Solicitud interpretada incorrectamente.
- Captura tratada como inspiración y no como referencia exacta.
- Resultado esperado no documentado.
- Falta de ejemplos.
- Reglas comerciales incompletas.
- Diferencias entre teléfono y computadora no especificadas.
- Funciones agregadas sin autorización.

6. PERSONAS Y RESPONSABILIDADES

- Nadie verifica la versión principal.
- Nadie revisa seguridad.
- Nadie ejecuta pruebas.
- Nadie aprueba el diseño responsive.
- Nadie valida reglas comerciales.
- La misma persona programa y aprueba sin revisión.
- Falta de responsable del archivo estable.

7. HERRAMIENTAS

- No se utiliza Git.
- No existe linter.
- No existe formateador.
- No existen pruebas automáticas.
- No existe navegador automatizado.
- No existe revisión de dependencias.
- No existe servidor local.
- No se inspecciona el DOM.
- No se revisa la consola.
- No existe análisis estático.

8. DATOS Y ENTORNOS

- Datos de prueba diferentes a los reales.
- Esquemas antiguos.
- Navegadores distintos.
- Caché.
- PWA o Service Worker.
- file:// frente a servidor local.
- Pantallas de diferentes tamaños.
- Almacenamiento lleno.
- Permisos diferentes.
- Importaciones antiguas.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CAMBIO OBLIGATORIO DEL PROCESO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cuando Ishikawa confirme una causa repetitiva, no basta con corregir nuevamente
el código.

Debe implementarse al menos una medida preventiva.

Las medidas preventivas pueden incluir:

- Unificar componentes duplicados.
- Separar responsabilidades.
- Crear una función central de guardado.
- Crear una función central de validación.
- Introducir IDs únicos.
- Implementar delegación de eventos.
- Eliminar funciones sobrescritas.
- Crear migraciones de datos.
- Añadir pruebas automatizadas.
- Añadir prueba de regresión.
- Añadir validación de seguridad.
- Crear una lista de comprobación.
- Introducir Git.
- Definir una fuente única del proyecto.
- Agregar linting.
- Agregar formateo automático.
- Agregar validación de HTML.
- Agregar análisis de dependencias.
- Separar módulos gradualmente.
- Documentar el comportamiento esperado.
- Establecer responsables de revisión.
- Probar en tamaños de pantalla obligatorios.

Cada medida preventiva debe indicar:

- Problema que previene.
- Responsable.
- Momento en que se ejecuta.
- Evidencia requerida.
- Prueba asociada.
- Criterio de aprobación.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CAPA DE PREVENCIÓN DE REGRESIONES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Todo error crítico corregido debe producir al menos una prueba de regresión.

Ejemplos:

Error:

Una venta se registra dos veces por doble clic.

Prevención:

- Bloquear el botón durante el procesamiento.
- Crear ID único.
- Agregar prueba de doble clic.

Error:

Los códigos alternativos desaparecen al editar.

Prevención:

- Separar estado temporal y datos guardados.
- Agregar prueba Crear → Guardar → Recargar → Editar.

Error:

Una configuración desactivada vuelve a activarse.

Prevención:

- Unificar carga y guardado de configuración.
- Agregar prueba Desactivar → Recargar → Confirmar.

Error:

El formulario cambia de estructura en teléfono.

Prevención:

- Agregar prueba visual en 320, 360, 390 y 430 píxeles.
- Revisar reglas responsive contradictorias.

Error:

Se aplicó una corrección sobre un archivo antiguo.

Prevención:

- Mostrar versión interna del sistema.
- Confirmar hash o fecha del archivo.
- Usar una sola rama principal.
- Prohibir modificaciones sin confirmar la base.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REGISTRO DE ERRORES REPETITIVOS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Mantener un registro de defectos repetitivos con:

- ID del patrón.
- Tipo de error.
- Primera aparición.
- Número de repeticiones.
- Módulos afectados.
- Causa raíz.
- Correcciones anteriores.
- Motivo por el que reapareció.
- Cambio de proceso aplicado.
- Prueba preventiva creada.
- Responsable.
- Estado.

Estados:

- Detectado.
- En análisis.
- Causa confirmada.
- Proceso modificado.
- Prueba preventiva creada.
- En observación.
- Cerrado.
- Reabierto.

Un patrón solo puede cerrarse cuando:

- La causa raíz está confirmada.
- Se corrigió el defecto actual.
- Se modificó el proceso.
- Existe una prueba preventiva.
- Se ejecutó una prueba de regresión.
- No reapareció en las verificaciones posteriores.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REGLA DE LAS DOS REPETICIONES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cuando el mismo tipo de defecto aparezca dos veces:

- No aplicar únicamente otro parche.
- No crear inmediatamente una nueva versión.
- Detener los cambios relacionados.
- Registrar el patrón.
- Aplicar Ishikawa.
- Reunir al equipo técnico.
- Confirmar la causa raíz.
- Cambiar el proceso que generó el defecto.
- Crear una prueba preventiva.
- Reanudar el desarrollo únicamente después de documentar la medida.

Esta regla también se activa cuando dos errores diferentes tienen el mismo
origen.

Ejemplo:

- Un botón dinámico no funciona.
- Otro botón dinámico tampoco funciona.

Aunque sean botones diferentes, ambos pueden pertenecer al mismo patrón:

“Los eventos se pierden porque los elementos se reconstruyen mediante
innerHTML sin delegación de eventos.”

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ORDEN DEFINITIVO DE TRABAJO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El orden obligatorio del proyecto será:

1. Confirmar el archivo principal.
2. Crear respaldo.
3. Ejecutar auditoría.
4. Clasificar riesgos.
5. Parchear errores críticos.
6. Parchear vulnerabilidades críticas.
7. Ejecutar pruebas de estabilización.
8. Verificar ventas, inventario y caja.
9. Verificar almacenamiento.
10. Verificar teléfono.
11. Verificar computadora.
12. Documentar parches.
13. Buscar patrones repetitivos.
14. Activar Ishikawa cuando corresponda.
15. Reunir las perspectivas del equipo.
16. Confirmar causa raíz.
17. Aplicar los cinco porqués.
18. Cambiar el proceso de desarrollo.
19. Crear pruebas preventivas.
20. Ejecutar regresiones.
21. Documentar la mejora.
22. Continuar con nuevas funciones.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FORMATO DEL INFORME FINAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

AUDITORÍA Y ESTABILIZACIÓN

Archivo analizado:
Versión:
Fecha:
Entorno:

Resumen ejecutivo:

Errores críticos:
- ID:
- Módulo:
- Riesgo:
- Causa:
- Parche:
- Prueba:
- Estado:

Vulnerabilidades:
- ID:
- Gravedad:
- Vector:
- Consecuencia:
- Mitigación:
- Estado:

Riesgos de datos:
- Descripción:
- Evidencia:
- Corrección:
- Prueba:

Pruebas de estabilización:
- Productos:
- Ventas:
- Inventario:
- Caja:
- Pagos:
- Almacenamiento:
- Teléfono:
- Computadora:

ANÁLISIS DE REPETICIÓN

Patrones encontrados:
- Patrón:
- Número de apariciones:
- Módulos:
- Causa probable:

ISHIKAWA

Problema central:

Ramas analizadas:

Hipótesis:

Experimentos:

Causa raíz:

Cinco porqués:

CAMBIO DEL PROCESO

Proceso anterior:

Debilidad encontrada:

Proceso nuevo:

Medida preventiva:

Prueba de regresión creada:

Responsable:

Criterio de aprobación:

ESTADO FINAL

- Sistema estabilizado.
- Sistema parcialmente estabilizado.
- Existen riesgos pendientes.
- Requiere aislamiento.
- Requiere refactorización.
- Requiere backend.
- Requiere pruebas en dispositivo real.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PRINCIPIO CENTRAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Primero protege y estabiliza el sistema.

Después investiga por qué los errores nacieron.

Finalmente cambia el proceso para impedir que vuelvan a producirse.

No debe confundirse:

- Parchear corrige el defecto actual.
- Ishikawa encuentra el origen del patrón.
- Cambiar el proceso evita la repetición.
- La prueba de regresión demuestra que la prevención funciona.

Una corrección sin prevención puede volver a fallar.

Una investigación sin parche deja al sistema expuesto.

Por eso ambos procesos son obligatorios y deben ejecutarse en ese orden:

AUDITORÍA → PARCHE CRÍTICO → ESTABILIZACIÓN → ISHIKAWA →
CAMBIO DEL PROCESO → PRUEBA PREVENTIVA.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

---

# Apéndice técnico detallado del Diagrama de Ishikawa

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
35. DIAGRAMA DE ISHIKAWA PARA DIAGNÓSTICO DE PROGRAMACIÓN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Además de la auditoría técnica normal, el programador debe utilizar el
Diagrama de Ishikawa, también conocido como diagrama de causa y efecto o
diagrama de espina de pescado, para investigar errores complejos.

Este método debe emplearse cuando:

- La auditoría inicial no encuentra la causa exacta.
- El problema continúa después de una corrección.
- Una función funciona en computadora, pero no en teléfono.
- Una función funciona una vez y después deja de funcionar.
- Un botón se muestra correctamente, pero no ejecuta su acción.
- Los datos se guardan, pero desaparecen después de recargar.
- Un problema reaparece después de modificar otro módulo.
- Existen varias funciones con nombres similares.
- Existen reglas CSS contradictorias.
- Existen resultados diferentes según el navegador.
- La consola no muestra un error claro.
- El problema aparece únicamente con determinados productos o datos.
- El sistema entra en un ciclo de corrección y regresión.
- Se realizaron dos intentos de corrección sin resolver completamente el error.
- La causa aparente no coincide con el comportamiento real.
- El programador no puede demostrar por qué ocurre el error.

El Diagrama de Ishikawa no debe utilizarse únicamente como una explicación
teórica o decorativa. Debe convertirse en un proceso técnico real de
investigación, comprobación y eliminación de hipótesis.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
36. PROBLEMA CENTRAL DEL DIAGRAMA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Antes de construir el diagrama, definir el problema central con una frase
precisa, observable y verificable.

Ejemplos correctos:

- El botón “Añadir otro código de barras” no crea una fila nueva.
- Los productos desaparecen después de recargar la página.
- El botón Pagar no abre el modal de cobro.
- El carrito se vacía al cambiar de módulo.
- La configuración desactivada vuelve a activarse después de recargar.
- El modal de producto no permite desplazarse hasta Guardar en Android.
- El ticket duplica la cantidad del producto.
- El pago mixto registra todo el total como efectivo.
- El código alternativo se guarda, pero el buscador no lo reconoce.
- La categoría nueva aparece en inventario, pero no aparece en el POS.

Ejemplos incorrectos:

- El sistema está mal.
- No funciona.
- Hay un error.
- La interfaz está rara.
- El código tiene problemas.

El problema central debe incluir, cuando sea posible:

- Qué función falla.
- Qué acción produce el fallo.
- En qué dispositivo ocurre.
- En qué navegador ocurre.
- Con qué datos ocurre.
- Qué resultado se esperaba.
- Qué resultado se obtuvo.

Formato recomendado:

PROBLEMA:
[Función] falla cuando [acción o condición] en [entorno], produciendo
[resultado incorrecto] en lugar de [resultado esperado].

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
37. CATEGORÍAS DEL DIAGRAMA DE ISHIKAWA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Para investigar un error de programación, analizar obligatoriamente las
siguientes ramas.

1. CÓDIGO Y LÓGICA

Revisar:

- Funciones incorrectas.
- Funciones duplicadas.
- Funciones sobrescritas.
- Funciones declaradas después de ser utilizadas.
- Variables globales modificadas accidentalmente.
- Variables con nombres iguales.
- Condiciones incorrectas.
- Retornos anticipados.
- Bucles infinitos.
- Promesas sin await.
- Errores asincrónicos.
- Excepciones silenciadas.
- Conversión incorrecta de números.
- Comparaciones entre texto y número.
- Valores null o undefined.
- Selectores que no encuentran elementos.
- Arrays modificados directamente.
- Objetos compartidos por referencia.
- Datos filtrados antes de ser guardados.
- Normalizaciones que eliminan información válida.
- Funciones antiguas todavía activas.
- Orden incorrecto de ejecución.
- Dependencias ocultas entre módulos.

Preguntas obligatorias:

- ¿La función que se está ejecutando es realmente la última versión?
- ¿Existe otra función con el mismo nombre?
- ¿La función retorna antes de completar el proceso?
- ¿Una validación está rechazando el dato?
- ¿El valor cambia de tipo?
- ¿El array se modifica antes de mostrarse?
- ¿Una normalización elimina filas vacías necesarias para la interfaz?
- ¿Una función posterior sobrescribe el resultado?

2. HTML Y ESTRUCTURA DEL DOM

Revisar:

- IDs duplicados.
- IDs inexistentes.
- Botones sin type="button".
- Botones dentro de formularios que envían el formulario accidentalmente.
- Elementos creados dinámicamente sin eventos.
- Elementos ocultos mediante hidden.
- Elementos ocultos mediante display:none.
- Estructura HTML mal cerrada.
- Modales anidados incorrectamente.
- Campos fuera del contenedor esperado.
- Atributos incorrectos.
- Eventos inline eliminados o reemplazados.
- Nombres de campos diferentes entre HTML y JavaScript.
- Elementos creados después de registrar eventos.
- Botones cubiertos por otro elemento.
- Elementos deshabilitados.
- Campos requeridos invisibles.

Preguntas obligatorias:

- ¿El elemento existe cuando se ejecuta el código?
- ¿El ID coincide exactamente?
- ¿Existen varios elementos con el mismo ID?
- ¿El botón está enviando un formulario?
- ¿El elemento dinámico recibe su evento?
- ¿Otro elemento transparente está bloqueando el toque?
- ¿El campo está oculto, deshabilitado o fuera del modal?

3. CSS Y DISEÑO RESPONSIVE

Revisar:

- Reglas CSS contradictorias.
- Media queries demasiado generales.
- Uso incorrecto de display:none.
- Uso incorrecto de overflow:hidden.
- Z-index.
- Position fixed.
- Position sticky.
- Alturas máximas.
- Anchos mínimos.
- Elementos fuera de la pantalla.
- Scroll bloqueado.
- Contenedores con pointer-events:none.
- Elementos superpuestos.
- Botones visualmente activos, pero inaccesibles.
- Reglas para teléfono que destruyen la estructura de computadora.
- Reglas para computadora que no se restablecen.
- Selectores demasiado generales.
- Estilos antiguos que siguen vigentes.
- Propiedades con !important.
- Transformaciones que cambian el área táctil.
- Teclado móvil que cubre controles.

Preguntas obligatorias:

- ¿El botón recibe realmente el toque?
- ¿Existe un elemento encima?
- ¿El modal permite scroll?
- ¿Una media query está cambiando la distribución?
- ¿La regla CSS pertenece a una versión anterior?
- ¿Existe un !important que impide el nuevo diseño?
- ¿El problema aparece únicamente en un ancho determinado?

4. EVENTOS E INTERACCIÓN

Revisar:

- addEventListener no registrado.
- Evento registrado varias veces.
- Evento eliminado.
- onclick apuntando a una función inexistente.
- Diferencia entre click, touchstart y pointerdown.
- Delegación de eventos incorrecta.
- stopPropagation.
- preventDefault.
- Eventos agregados antes de cargar el DOM.
- Eventos que se pierden al reconstruir innerHTML.
- Botones dinámicos sin delegación.
- Doble ejecución del evento.
- Campos que activan submit.
- Teclas Enter que ejecutan una acción diferente.
- Eventos bloqueados por un modal.
- Eventos registrados sobre elementos antiguos.

Preguntas obligatorias:

- ¿El evento se dispara?
- ¿Cuántas veces se dispara?
- ¿El elemento fue reemplazado después de registrar el evento?
- ¿La función asociada existe en window?
- ¿preventDefault está bloqueando el comportamiento?
- ¿innerHTML eliminó los eventos anteriores?
- ¿El problema ocurre con toque, clic o ambos?

5. DATOS Y ESTADO DE LA APLICACIÓN

Revisar:

- Estado inicial incorrecto.
- Datos no normalizados.
- Datos antiguos incompatibles.
- Campos faltantes.
- Valores predeterminados incorrectos.
- Arrays vacíos.
- IDs repetidos.
- SKU duplicados.
- Códigos de barras duplicados.
- Estado del modal no reiniciado.
- Estado de edición mezclado con creación.
- Carrito no sincronizado.
- Producto seleccionado incorrecto.
- Datos filtrados antes de guardar.
- Tipos de datos diferentes.
- Fechas inválidas.
- Números guardados como texto.
- Valores booleanos guardados como cadenas.
- Datos temporales que sustituyen los persistentes.

Preguntas obligatorias:

- ¿El error ocurre con todos los productos o solo con algunos?
- ¿Los datos antiguos tienen la misma estructura?
- ¿El estado se limpia al cerrar el modal?
- ¿Crear y editar usan el mismo estado?
- ¿Existe un ID duplicado?
- ¿El valor guardado es número, texto, booleano, array u objeto?
- ¿La interfaz muestra el estado real o una copia desactualizada?

6. ALMACENAMIENTO Y PERSISTENCIA

Revisar:

- localStorage.
- IndexedDB.
- sessionStorage.
- Cuotas de almacenamiento.
- JSON.parse.
- JSON.stringify.
- Datos circulares.
- Errores de escritura.
- Escritura asincrónica no esperada.
- Lectura antes de completar la escritura.
- Dos funciones guardando estados diferentes.
- Claves antiguas.
- Migraciones incompletas.
- Limpieza accidental.
- Restauración automática de un respaldo antiguo.
- Configuración guardada separadamente.
- Datos sobrescritos con valores predeterminados.
- Navegación privada.
- Restricciones del navegador.
- Diferencias entre dispositivos.

Preguntas obligatorias:

- ¿La función de guardado termina correctamente?
- ¿Qué clave se escribe?
- ¿Qué clave se lee?
- ¿Otra función vuelve a guardar datos antiguos?
- ¿El sistema carga valores predeterminados después de cargar datos reales?
- ¿Existe una migración de estructura?
- ¿El navegador dispone de espacio?
- ¿El dato se mantiene después de cerrar y abrir el navegador?

7. NAVEGADOR, DISPOSITIVO Y ENTORNO

Revisar:

- Chrome Android.
- Edge.
- Navegadores integrados.
- Modo incógnito.
- Permisos.
- Caché.
- Versión antigua del archivo.
- Service Worker.
- PWA.
- Archivo abierto mediante file://.
- Servidor local.
- HTTPS.
- Diferencias de API.
- Restricciones Bluetooth.
- Restricciones USB.
- Teclado virtual.
- Orientación.
- Memoria disponible.
- Tamaño de pantalla.
- Zoom del navegador.
- Sistema operativo.
- Compatibilidad con input type="date".
- Compatibilidad con impresión.

Preguntas obligatorias:

- ¿El usuario está abriendo el archivo actualizado?
- ¿El navegador conserva una versión en caché?
- ¿El problema ocurre en otro navegador?
- ¿Ocurre usando file:// y desaparece con servidor local?
- ¿La API requiere HTTPS?
- ¿El dispositivo tiene permisos?
- ¿El teclado modifica el tamaño visible?
- ¿La aplicación está instalada como PWA?
- ¿Existe un Service Worker sirviendo archivos antiguos?

8. PROCESO DE DESARROLLO Y VERSIONES

Revisar:

- Archivo base equivocado.
- Uso de una versión anterior.
- Cambios aplicados sobre una copia distinta.
- Versiones con nombres similares.
- Funciones copiadas entre versiones.
- Correcciones no integradas.
- Código de prueba dejado activo.
- Conflictos de combinación.
- Commits incompletos.
- Archivos duplicados.
- Cambios no guardados.
- Caché de compilación.
- Diferencias entre archivo fuente y archivo entregado.

Preguntas obligatorias:

- ¿Cuál es el archivo principal vigente?
- ¿La corrección se aplicó en ese archivo?
- ¿El usuario abrió el archivo correcto?
- ¿La versión entregada contiene realmente el cambio?
- ¿Se copiaron funciones antiguas?
- ¿Existe una diferencia entre el archivo probado y el archivo entregado?
- ¿Se realizó un respaldo antes de modificar?

9. REQUISITOS E INTERPRETACIÓN

Revisar:

- Solicitud ambigua.
- Diseño interpretado como inspiración.
- Orden de campos diferente.
- Función agregada sin ser solicitada.
- Elemento ocultado sin autorización.
- Diferencia entre “compactar” y “rediseñar”.
- Diferencia entre “añadir” y “reemplazar”.
- Referencia visual no respetada.
- Comportamiento esperado no documentado.
- Reglas comerciales incompletas.
- Excepciones no consideradas.
- Diferencias entre teléfono y computadora.

Preguntas obligatorias:

- ¿Qué pidió exactamente el usuario?
- ¿Solicitó cambiar diseño o solo ordenar?
- ¿La imagen era una referencia exacta?
- ¿Se mantuvieron las funciones anteriores?
- ¿Se agregaron decisiones que el usuario no pidió?
- ¿El resultado esperado está definido con ejemplos?
- ¿La función debe comportarse igual en teléfono y computadora?

10. PRUEBAS Y CONTROL DE CALIDAD

Revisar:

- Prueba no ejecutada.
- Prueba realizada solo en computadora.
- Prueba realizada solo en teléfono.
- Caso ideal probado, pero no casos límite.
- Datos de prueba diferentes a los reales.
- Consola no revisada.
- Errores silenciosos.
- Persistencia no probada.
- Regresión no probada.
- Botón probado visualmente, pero no funcionalmente.
- Prueba realizada en otro archivo.
- Prueba incompleta.
- Falta de evidencia.

Preguntas obligatorias:

- ¿Se reprodujo el error antes de corregir?
- ¿Se volvió a reproducir después?
- ¿Se revisó la consola?
- ¿Se probó después de recargar?
- ¿Se probó con datos antiguos?
- ¿Se probó en teléfono?
- ¿Se probó en computadora?
- ¿Se probaron funciones relacionadas?
- ¿Se verificó que no aparecieron regresiones?

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
38. PROCEDIMIENTO OBLIGATORIO DEL DIAGRAMA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cuando se active el análisis Ishikawa, seguir este procedimiento:

PASO 1: CONGELAR LOS CAMBIOS

No continuar modificando código por intuición.

No crear una nueva versión inmediatamente.

No aplicar parches adicionales hasta reunir evidencia.

Guardar el estado actual mediante:

- Commit.
- Copia de seguridad.
- Etiqueta temporal.
- Registro del archivo analizado.

PASO 2: REPRODUCIR EL PROBLEMA

Documentar:

- Acción exacta.
- Resultado esperado.
- Resultado obtenido.
- Dispositivo.
- Navegador.
- Tamaño de pantalla.
- Datos utilizados.
- Mensajes de consola.
- Frecuencia del fallo.

Clasificar:

- Siempre ocurre.
- Ocurre algunas veces.
- Solo ocurre después de recargar.
- Solo ocurre en edición.
- Solo ocurre al crear.
- Solo ocurre en teléfono.
- Solo ocurre con datos antiguos.
- Solo ocurre después de usar otro módulo.

PASO 3: DEFINIR EL EFECTO

Escribir el problema central de forma precisa.

PASO 4: CONSTRUIR LAS RAMAS

Analizar como mínimo:

- Código y lógica.
- HTML y DOM.
- CSS y responsive.
- Eventos.
- Datos y estado.
- Almacenamiento.
- Navegador y dispositivo.
- Versiones.
- Requisitos.
- Pruebas.

PASO 5: GENERAR HIPÓTESIS

Cada causa posible debe escribirse como hipótesis verificable.

Ejemplo:

HIPÓTESIS 1:
La fila nueva se crea, pero la función de normalización elimina inmediatamente
los códigos vacíos.

HIPÓTESIS 2:
El botón apunta a una función antigua sobrescrita por otra declaración.

HIPÓTESIS 3:
El elemento se agrega al DOM, pero una regla CSS lo mantiene oculto.

HIPÓTESIS 4:
innerHTML reconstruye el contenedor y elimina los eventos.

No utilizar hipótesis vagas como:

- Tal vez es el navegador.
- Debe ser el CSS.
- Parece un problema del código.

PASO 6: ASIGNAR EVIDENCIA

Para cada hipótesis registrar:

- Evidencia a favor.
- Evidencia en contra.
- Prueba necesaria.
- Resultado de la prueba.
- Estado.

Estados permitidos:

- No comprobada.
- Confirmada.
- Descartada.
- Parcialmente confirmada.
- Requiere más información.

PASO 7: REALIZAR EXPERIMENTOS AISLADOS

Cada prueba debe cambiar una sola variable.

Ejemplos:

- Registrar en consola si se ejecuta el evento.
- Confirmar si la fila aparece en el DOM.
- Desactivar temporalmente la normalización.
- Revisar si el array aumenta.
- Desactivar una regla CSS.
- Probar sin caché.
- Probar con producto nuevo.
- Probar con producto antiguo.
- Probar en otro navegador.
- Probar con archivo servido localmente.

No modificar varias partes al mismo tiempo porque se perdería la capacidad de
identificar la causa real.

PASO 8: IDENTIFICAR LA CAUSA RAÍZ

No aceptar como causa raíz:

- El botón no funciona.
- JavaScript falla.
- CSS lo oculta.
- El navegador tiene un problema.

La causa raíz debe ser específica.

Ejemplo:

“La función addAlternativeBarcode() agrega una cadena vacía al array, pero
renderAlternativeBarcodes() ejecuta filter(Boolean) antes de renderizar. La
cadena vacía se elimina en el mismo ciclo, por lo que la fila nunca se muestra.”

PASO 9: APLICAR LOS CINCO PORQUÉS

Después de identificar una causa, preguntar “¿por qué?” hasta llegar al origen
del diseño o proceso.

Ejemplo:

1. ¿Por qué no aparece la fila?
   Porque el array no conserva cadenas vacías.

2. ¿Por qué no conserva cadenas vacías?
   Porque se aplica filter(Boolean).

3. ¿Por qué se aplica filter(Boolean)?
   Porque la función fue creada inicialmente para preparar datos antes de guardar.

4. ¿Por qué se utiliza también al renderizar?
   Porque la misma función se reutilizó para almacenamiento e interfaz.

5. ¿Por qué es incorrecto reutilizarla?
   Porque el estado de edición necesita conservar filas vacías temporalmente,
   mientras el almacenamiento debe eliminarlas.

Causa raíz de diseño:

Se mezclaron dos responsabilidades:
- Estado temporal de la interfaz.
- Datos definitivos de almacenamiento.

Solución correcta:

Separar:
- normalizeAlternativeCodesForUI().
- sanitizeAlternativeCodesForSave().

PASO 10: DISEÑAR LA CORRECCIÓN

La corrección debe atacar la causa raíz.

No utilizar parches visuales para ocultar el síntoma.

Antes de programar, definir:

- Archivo afectado.
- Función afectada.
- Estado afectado.
- Datos afectados.
- Riesgos.
- Pruebas necesarias.
- Funciones que no deben modificarse.

PASO 11: IMPLEMENTAR CAMBIO MÍNIMO

Modificar únicamente lo necesario.

Evitar:

- Reescribir todo el módulo.
- Cambiar la interfaz sin necesidad.
- Cambiar nombres no relacionados.
- Crear funciones duplicadas.
- Introducir otra fuente de estado.
- Eliminar validaciones.
- Borrar datos para resolver incompatibilidades.

PASO 12: PRUEBA DE CORRECCIÓN

Probar específicamente el problema.

PASO 13: PRUEBA DE REGRESIÓN

Probar funciones relacionadas para verificar que la solución no causó nuevos
errores.

PASO 14: DOCUMENTAR

Registrar:

- Problema.
- Causa raíz.
- Hipótesis descartadas.
- Solución.
- Archivos.
- Funciones.
- Pruebas.
- Resultado.
- Riesgos pendientes.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
39. TABLA DE HIPÓTESIS DEL ISHIKAWA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Durante un diagnóstico complejo, utilizar este formato:

PROBLEMA CENTRAL:
[Descripción exacta]

ENTORNO:
- Archivo:
- Versión:
- Dispositivo:
- Navegador:
- Tamaño de pantalla:
- Datos utilizados:
- Fecha de prueba:

HIPÓTESIS 1
Categoría:
Causa posible:
Evidencia a favor:
Evidencia en contra:
Prueba:
Resultado:
Estado:

HIPÓTESIS 2
Categoría:
Causa posible:
Evidencia a favor:
Evidencia en contra:
Prueba:
Resultado:
Estado:

HIPÓTESIS 3
Categoría:
Causa posible:
Evidencia a favor:
Evidencia en contra:
Prueba:
Resultado:
Estado:

CAUSA RAÍZ CONFIRMADA:
[Explicación técnica exacta]

CORRECCIÓN PROPUESTA:
[Descripción]

RIESGO DE REGRESIÓN:
[Descripción]

PRUEBAS OBLIGATORIAS:
[Casos]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
40. NIVELES DE ESCALAMIENTO DEL DIAGNÓSTICO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

NIVEL 1: REVISIÓN DIRECTA

Utilizar cuando:

- El error es claro.
- Existe un mensaje de consola.
- La función afectada está identificada.
- La corrección es localizada.

Acciones:

- Reproducir.
- Revisar función.
- Corregir.
- Probar.

NIVEL 2: AUDITORÍA TÉCNICA

Utilizar cuando:

- No está clara la función responsable.
- Hay varias funciones relacionadas.
- Puede existir código duplicado.
- Puede existir conflicto de estado.
- Puede existir incompatibilidad de datos.

Acciones:

- Revisar DOM.
- Revisar JavaScript.
- Revisar almacenamiento.
- Revisar eventos.
- Revisar CSS.
- Revisar consola.
- Revisar flujo completo.

NIVEL 3: DIAGRAMA DE ISHIKAWA

Utilizar cuando:

- La auditoría no identifica la causa.
- La primera corrección no funciona.
- El problema reaparece.
- Existe comportamiento diferente entre dispositivos.
- Hay varias causas posibles.
- No existe evidencia suficiente.
- El sistema entra en un bucle de correcciones.

Acciones:

- Congelar cambios.
- Definir problema central.
- Crear ramas.
- Formular hipótesis.
- Ejecutar experimentos.
- Aplicar cinco porqués.
- Confirmar causa raíz.
- Corregir.
- Probar regresión.

NIVEL 4: AISLAMIENTO DEL MÓDULO

Utilizar cuando Ishikawa no ofrece evidencia concluyente.

Acciones:

- Crear una copia temporal de prueba.
- Extraer únicamente el módulo afectado.
- Eliminar dependencias no necesarias.
- Reproducir el error en entorno mínimo.
- Agregar registros de diagnóstico.
- Comparar comportamiento aislado con el sistema completo.

El aislamiento no debe reemplazar el archivo principal.

Debe utilizarse únicamente para diagnóstico.

NIVEL 5: REVISIÓN DE ARQUITECTURA

Utilizar cuando:

- El problema se debe a código excesivamente acoplado.
- Existen funciones globales sobrescritas.
- Varias partes modifican el mismo estado.
- El archivo único ya no permite correcciones seguras.
- Los errores reaparecen por diseño estructural.

Acciones:

- Elaborar mapa de dependencias.
- Separar responsabilidades.
- Crear módulos.
- Introducir estado centralizado.
- Crear capa de almacenamiento.
- Crear pruebas automatizadas.
- Refactorizar por etapas.

No realizar una refactorización completa sin autorización.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
41. EJEMPLO ISHIKAWA: BOTÓN DE CÓDIGOS ALTERNATIVOS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PROBLEMA CENTRAL:

Al presionar “Añadir otro código de barras”, el sistema no muestra un nuevo
campo para escribir el código alternativo.

RAMA: CÓDIGO

Posibles causas:

- La función no agrega un elemento al array.
- El array alcanza incorrectamente el límite.
- La fila vacía es eliminada por filter(Boolean).
- La función retorna anticipadamente.
- Se utiliza una función antigua.
- La función está sobrescrita.

RAMA: DOM

Posibles causas:

- El contenedor no existe.
- El ID del contenedor es incorrecto.
- La fila se agrega a otro elemento.
- El HTML generado no se inserta.
- Existen IDs duplicados.

RAMA: EVENTOS

Posibles causas:

- El botón no tiene evento.
- El onclick apunta a una función inexistente.
- El elemento fue reemplazado mediante innerHTML.
- El botón ejecuta submit.
- El evento es bloqueado.

RAMA: CSS

Posibles causas:

- La fila tiene display:none.
- El contenedor tiene overflow:hidden.
- La nueva fila aparece fuera del área visible.
- Otro elemento la cubre.
- Una media query la oculta.

RAMA: ESTADO

Posibles causas:

- El array se reinicia después de agregar.
- Crear y editar utilizan estados diferentes.
- La función de render utiliza otra variable.
- El contador utiliza una fuente diferente.

RAMA: VERSIONES

Posibles causas:

- Se abrió una versión antigua.
- El cambio fue aplicado a otro archivo.
- El navegador conserva caché.
- La función nueva fue reemplazada por código antiguo.

EXPERIMENTOS:

1. Registrar la ejecución del evento.
2. Registrar longitud del array antes y después.
3. Inspeccionar el DOM.
4. Comprobar estilos calculados.
5. Buscar funciones duplicadas.
6. Probar sin filter(Boolean).
7. Probar con caché deshabilitada.
8. Confirmar nombre y versión del archivo.

CAUSA RAÍZ DE EJEMPLO:

La función agrega una cadena vacía al array, pero el renderizado aplica
filter(Boolean). La cadena vacía se elimina inmediatamente y la interfaz no
muestra la fila.

CORRECCIÓN:

Conservar filas vacías en el estado temporal de la interfaz y eliminar códigos
vacíos únicamente al guardar el producto.

PRUEBAS:

- Añadir una fila.
- Añadir diez filas.
- Intentar añadir la undécima.
- Escribir códigos.
- Eliminar una fila.
- Guardar.
- Recargar.
- Editar.
- Verificar búsqueda.
- Verificar duplicados.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
42. PREVENCIÓN DE BUCLES DE CORRECCIÓN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Se considera que existe un bucle de corrección cuando:

- Se corrige la misma función más de una vez.
- Cada versión cambia el diseño sin resolver el comportamiento.
- Una solución restaura un error anterior.
- El archivo base cambia entre intentos.
- Se agregan parches sin confirmar la causa.
- Se afirma que una función está corregida sin prueba.
- El usuario reporta repetidamente el mismo fallo.

Cuando se detecte un bucle:

1. Detener nuevas modificaciones.
2. No generar otra versión inmediatamente.
3. Confirmar el archivo exacto.
4. Reproducir el error.
5. Abrir la consola.
6. Aplicar auditoría.
7. Aplicar Ishikawa.
8. Formular hipótesis.
9. Confirmar causa raíz.
10. Aplicar un único cambio controlado.
11. Ejecutar pruebas de regresión.
12. Entregar evidencia del resultado.

No continuar creando archivos v50, v51, v52 o similares sin haber identificado
la causa raíz del problema repetitivo.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
43. FORMATO DE INFORME ISHIKAWA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cuando se utilice este método, responder con el siguiente formato:

DIAGNÓSTICO ISHIKAWA

Problema central:
[Descripción]

Entorno:
[Archivo, dispositivo, navegador y condiciones]

Ramas analizadas:
- Código.
- DOM.
- CSS.
- Eventos.
- Estado.
- Almacenamiento.
- Entorno.
- Versiones.
- Requisitos.
- Pruebas.

Hipótesis principales:
1. [Hipótesis]
2. [Hipótesis]
3. [Hipótesis]

Experimentos realizados:
1. [Prueba y resultado]
2. [Prueba y resultado]
3. [Prueba y resultado]

Hipótesis descartadas:
- [Causa descartada y evidencia]

Causa raíz confirmada:
[Explicación técnica]

Cinco porqués:
1. [Por qué]
2. [Por qué]
3. [Por qué]
4. [Por qué]
5. [Origen]

Corrección aplicada:
[Cambio exacto]

Archivos modificados:
[Archivos]

Funciones modificadas:
[Funciones]

Pruebas de corrección:
[Resultados]

Pruebas de regresión:
[Resultados]

Riesgos pendientes:
[Limitaciones reales]

Estado final:
- Resuelto.
- Parcialmente resuelto.
- No resuelto.
- Requiere aislamiento.
- Requiere revisión arquitectónica.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
44. REGLA DE HONESTIDAD TÉCNICA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cuando el problema no pueda resolverse, el programador debe indicarlo con
claridad.

No debe:

- Fingir una corrección.
- Crear un archivo sin cambios reales.
- afirmar que se ejecutaron pruebas inexistentes.
- Ocultar que faltan herramientas.
- Culpar automáticamente al dispositivo.
- Culpar automáticamente al navegador.
- Repetir la misma solución.
- Modificar diseño para disimular el fallo.

Debe informar:

- Qué se comprobó.
- Qué hipótesis fueron descartadas.
- Qué evidencia falta.
- Qué prueba no pudo realizarse.
- Qué herramienta sería necesaria.
- Qué parte debe aislarse.
- Qué riesgo existe al continuar modificando sin causa confirmada.

El objetivo es resolver el problema correctamente, no producir una nueva
versión de archivo por cada intento.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
45. ORDEN OBLIGATORIO PARA RESOLVER PROBLEMAS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El orden definitivo de diagnóstico será:

1. Comprender la solicitud.
2. Confirmar archivo principal.
3. Reproducir el error.
4. Revisar consola.
5. Realizar inspección directa.
6. Realizar auditoría técnica.
7. Aplicar Diagrama de Ishikawa si continúa la incertidumbre.
8. Aplicar los cinco porqués.
9. Aislar el módulo si fuera necesario.
10. Confirmar la causa raíz.
11. Diseñar una corrección mínima.
12. Crear respaldo o commit.
13. Implementar.
14. Probar el caso principal.
15. Probar casos límite.
16. Probar regresiones.
17. Probar en teléfono.
18. Probar en computadora.
19. Documentar resultados.
20. Entregar únicamente cuando exista evidencia suficiente.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FIN DEL SISTEMA DE DIAGNÓSTICO ISHIKAWA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
