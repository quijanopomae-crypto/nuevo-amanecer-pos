# Contexto, reglas, arquitectura, versiones, responsive e identidad visual

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROYECTO: SISTEMA POS MULTISERVICIOS NUEVO AMANECER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. IDENTIDAD DEL PROYECTO

Nombre del sistema:
Sistema POS Nuevo Amanecer

Nombre comercial:
Multiservicios Nuevo Amanecer

Ubicación:
Puerto Súngaro, provincia de Puerto Inca, región Huánuco, Perú.

Cajero predeterminado:
Frank

Tipo de sistema:
Punto de venta, inventario, caja, ventas, clientes, créditos, gastos,
configuración, seguridad, respaldos e impresión térmica.

Plataformas objetivo:
- Teléfonos Android.
- Tablets.
- Computadoras de escritorio.
- Laptops.
- Navegadores modernos como Chrome, Edge y navegadores basados en Chromium.

El sistema debe funcionar correctamente tanto en pantallas pequeñas como grandes.
No se debe diseñar únicamente para computadora ni únicamente para teléfono.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
2. ROL QUE DEBE ASUMIR CHATGPT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Actúa como un equipo profesional compuesto por:

- Programador senior full stack.
- Especialista en JavaScript.
- Especialista en HTML y CSS responsive.
- Diseñador UX/UI para sistemas comerciales.
- Especialista en puntos de venta.
- Especialista en inventarios.
- Especialista en almacenamiento local y bases de datos.
- Especialista en impresión térmica.
- Analista de errores y depuración.
- Ingeniero de control de calidad.
- Arquitecto de software.
- Especialista en seguridad de aplicaciones.
- Diseñador creativo, pero disciplinado.

Debes ser creativo al proponer soluciones, pero nunca cambiar la estructura,
el diseño o las funciones sin autorización.

No debes interpretar una captura solo como inspiración cuando el usuario indique
que debe verse igual o con el mismo orden.

Cuando una imagen sea usada como referencia:

1. Analiza el orden exacto de los campos.
2. Identifica cuántas columnas tiene.
3. Respeta los tamaños relativos.
4. Respeta qué elementos están juntos.
5. Respeta cuáles opciones están visibles.
6. Respeta cuáles opciones están ocultas.
7. No agregues elementos visuales innecesarios.
8. No cambies la estructura por una interpretación propia.
9. Comprueba el resultado en teléfono y computadora.

El objetivo no es solamente generar código. El objetivo es producir un sistema
estable, rápido, fácil de usar, profesional y preparado para crecer.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
3. PROPÓSITO PRINCIPAL DEL SISTEMA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El Sistema POS Nuevo Amanecer permite administrar las operaciones diarias de
Multiservicios Nuevo Amanecer desde un teléfono o una computadora.

El sistema debe permitir:

- Registrar productos.
- Organizar productos por categorías.
- Controlar existencias.
- Registrar ventas.
- Cobrar mediante diferentes métodos.
- Realizar pagos mixtos.
- Calcular vuelto.
- Registrar ventas a crédito.
- Administrar clientes.
- Controlar caja.
- Registrar ingresos y egresos.
- Consultar ventas.
- Consultar inventario.
- Calcular ganancias potenciales.
- Emitir tickets térmicos.
- Imprimir mediante los medios disponibles.
- Configurar el negocio.
- Proteger funciones importantes mediante PIN.
- Importar y exportar información.
- Crear respaldos.
- Restaurar información.
- Mantener los datos después de recargar la página.
- Funcionar correctamente en Android y computadora.

El sistema debe priorizar:

- Rapidez.
- Claridad.
- Facilidad de uso.
- Seguridad.
- Persistencia de datos.
- Diseño profesional.
- Compatibilidad móvil.
- Compatibilidad con computadora.
- Prevención de errores.
- Flujo de venta rápido.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4. ESTADO TÉCNICO DEL PROYECTO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El proyecto comenzó como una aplicación web contenida principalmente en un
archivo HTML con:

- HTML.
- CSS.
- JavaScript.
- Almacenamiento local.
- Datos de productos.
- Interfaz responsive.
- Funciones de impresión.
- Módulos administrativos.

La aplicación puede ejecutarse localmente en el navegador.

Sin embargo, el proyecto ha crecido considerablemente. La versión final debe
evolucionar progresivamente hacia una estructura organizada.

Estructura recomendada:

Nuevo_Amanecer_POS/
│
├── index.html
│
├── css/
│   ├── variables.css
│   ├── general.css
│   ├── responsive.css
│   ├── dashboard.css
│   ├── pos.css
│   ├── productos.css
│   ├── inventario.css
│   ├── ventas.css
│   ├── caja.css
│   ├── clientes.css
│   ├── configuracion.css
│   ├── ticket.css
│   └── modales.css
│
├── js/
│   ├── app.js
│   ├── estado.js
│   ├── almacenamiento.js
│   ├── productos.js
│   ├── categorias.js
│   ├── inventario.js
│   ├── carrito.js
│   ├── ventas.js
│   ├── pagos.js
│   ├── caja.js
│   ├── clientes.js
│   ├── creditos.js
│   ├── gastos.js
│   ├── ticket.js
│   ├── impresion.js
│   ├── seguridad.js
│   ├── respaldos.js
│   └── validaciones.js
│
├── data/
│   ├── productos.json
│   ├── categorias.json
│   └── configuracion.json
│
├── tests/
│   ├── productos.test.js
│   ├── ventas.test.js
│   ├── inventario.test.js
│   ├── almacenamiento.test.js
│   ├── pagos.test.js
│   └── ticket.test.js
│
├── AGENTS.md
└── README.md

No se debe dividir el archivo de manera apresurada.

Primero:

1. Identificar funciones duplicadas.
2. Identificar dependencias.
3. Identificar variables globales.
4. Identificar eventos.
5. Identificar datos almacenados.
6. Crear un respaldo.
7. Separar progresivamente.
8. Probar después de cada separación.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
5. REGLAS FUNDAMENTALES DEL DESARROLLO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Trabajar siempre sobre el último archivo estable aprobado.

2. No utilizar una versión anterior como base.

3. Antes de modificar, comprobar el nombre del archivo base.

4. No eliminar funciones existentes sin autorización explícita.

5. No cambiar módulos no relacionados con la solicitud.

6. Realizar cambios pequeños, localizados y verificables.

7. No rediseñar toda la aplicación por una corrección pequeña.

8. No agregar funciones no solicitadas dentro de una corrección visual.

9. No ocultar funciones importantes sin autorización.

10. No afirmar que algo funciona sin haber revisado su lógica.

11. No afirmar que una prueba fue realizada si no se ejecutó realmente.

12. No generar errores silenciosos.

13. No dejar botones aparentemente activos cuando internamente están desactivados.

14. Mostrar mensajes claros cuando falta información.

15. Evitar alertas nativas como:
    - alert()
    - confirm()
    - prompt()

16. Utilizar modales propios del sistema.

17. Mantener la identidad visual verde esmeralda.

18. Evitar diseños excesivamente minimalistas.

19. Evitar diseños recargados o cansados visualmente.

20. El diseño debe sentirse como un sistema comercial completo.

21. Todos los botones deben tener respuesta visual.

22. Todos los botones deben tener una función real.

23. Todas las funciones desactivadas deben permanecer desactivadas después de
    recargar la página.

24. Los productos no deben desaparecer después de actualizar.

25. Los datos del carrito no deben desaparecer accidentalmente.

26. Los datos deben conservarse incluso después de recargar la página, siempre
    que la configuración correspondiente esté activa.

27. Las operaciones críticas deben validarse antes de guardarse.

28. Las ventas no deben anularse por un error visual del ticket.

29. El registro de la venta debe separarse del proceso de impresión.

30. El sistema debe funcionar sin bloquear el desplazamiento vertical.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
6. CONTROL DE VERSIONES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Debe existir una sola fuente principal del proyecto.

No crear v1, v2, v3, v4 para cada modificación pequeña dentro del proyecto.

Utilizar:

- Git.
- Commits.
- Ramas para cambios grandes.
- Etiquetas para versiones estables.

Ejemplo de commits:

- fix: corregir botón de códigos alternativos
- fix: mantener configuración después de recargar
- feat: agregar pago mixto
- feat: permitir diez códigos de barras
- ui: compactar formulario de productos
- refactor: separar lógica de inventario
- test: agregar prueba de venta en efectivo

Solo se genera un archivo compilado con versión cuando se alcance un punto
estable.

Ejemplo:

Nuevo_Amanecer_POS_1.0.0.html
Nuevo_Amanecer_POS_1.1.0.html

Antes de una modificación grande:

1. Crear commit.
2. Crear respaldo.
3. Identificar alcance.
4. Implementar.
5. Probar.
6. Revisar diferencias.
7. Aprobar.
8. Integrar.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
7. DISEÑO RESPONSIVE: TELÉFONO Y COMPUTADORA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

La aplicación debe funcionar desde aproximadamente 320 px de ancho hasta
pantallas grandes de computadora.

En teléfono:

- Botones cómodos para tocar.
- Sin elementos cortados.
- Sin desplazamiento horizontal innecesario.
- Desplazamiento vertical fluido.
- Modales adaptados a la pantalla.
- Teclado no debe ocultar botones importantes.
- Botones Guardar y Cancelar deben permanecer accesibles.
- Campos cortos pueden mantenerse en dos columnas cuando sea legible.
- Campos largos deben utilizar una columna.
- Productos deben mostrarse normalmente en dos columnas.
- Menú de configuración debe poder desplegarse con botón de tres rayas.
- El carrito debe ocupar un ancho adecuado.
- No debe bloquearse el scroll al abrir o cerrar modales.

En computadora:

- Aprovechar el ancho disponible.
- Mostrar más tarjetas por fila.
- Mantener espacios equilibrados.
- Evitar grandes zonas vacías.
- Permitir navegación rápida.
- Mostrar paneles administrativos más amplios.
- No estirar excesivamente campos de texto.
- Utilizar un ancho máximo razonable.
- Mantener una jerarquía visual clara.

Puntos de prueba obligatorios:

- 320 px.
- 360 px.
- 390 px.
- 430 px.
- 768 px.
- 1024 px.
- 1366 px.
- 1920 px.

No se debe utilizar una regla responsive que destruya la estructura solicitada.

Ejemplo de error que debe evitarse:

Convertir todas las filas de dos columnas en una columna sin analizar si los
campos todavía caben en teléfono.

SKU y código de barras pueden mostrarse juntos.
Costo y precio pueden mostrarse juntos.
Stock inicial y stock mínimo pueden mostrarse juntos.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
8. IDENTIDAD VISUAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Estilo general:

- Profesional.
- Moderno.
- Comercial.
- Vanguardista sin exageración.
- Fácil de comprender.
- Rápido de operar.
- Con buena jerarquía visual.

Color principal:
Verde esmeralda.

Colores secundarios:
- Blanco.
- Gris muy claro.
- Gris oscuro.
- Verde suave.
- Ámbar para advertencias.
- Rojo para errores.
- Azul o morado únicamente cuando tengan una función clara.

Evitar:

- Demasiados degradados.
- Demasiadas sombras.
- Iconos excesivos.
- Colores sin función.
- Tarjetas gigantes.
- Texto repetido.
- Accesos duplicados.
- Bloques decorativos que no aporten información.
- Interfaces demasiado vacías.
- Interfaces sobrecargadas.

Los colores del sistema no deben trasladarse al ticket térmico.
