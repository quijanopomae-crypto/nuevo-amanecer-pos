# Especificación funcional de módulos

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
9. PANEL PRINCIPAL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El panel principal debe ser pequeño, compacto y rápido de interpretar.

Debe mostrar:

- Saludo.
- Fecha.
- Resumen del negocio.
- Módulos principales.

El bloque superior debe ser aproximadamente 30% más pequeño que las primeras
versiones.

No debe repetir información.

Evitar duplicar:

- Ventas del día.
- Caja.
- Créditos.
- Productos cargados.
- Último movimiento.

Orden recomendado:

1. Panel principal compacto.
2. Resumen.
3. Módulos principales.

Resumen:

- Ventas de hoy.
- Dinero en caja.
- Monto por cobrar.
- Stock crítico.

Cada indicador debe ser compacto.

Módulos principales:

- Punto de Venta.
- Inventario.
- Ventas.
- Clientes.
- Caja.
- Gastos.
- Configuración.

No mostrar accesos rápidos que repitan exactamente los mismos módulos.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
10. PUNTO DE VENTA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El Punto de Venta debe permitir:

- Buscar productos.
- Buscar por nombre.
- Buscar por marca.
- Buscar por SKU.
- Buscar por código de barras principal.
- Buscar por códigos alternativos.
- Filtrar por categoría.
- Agregar productos al carrito.
- Cambiar cantidades.
- Eliminar productos.
- Limpiar carrito.
- Aplicar precio mayorista cuando corresponda.
- Mostrar stock.
- Bloquear productos sin stock cuando el control esté activo.
- Vender productos sin control de inventario.
- Calcular total.
- Procesar diferentes métodos de pago.
- Registrar la venta.
- Descontar stock.
- Registrar movimiento en caja.
- Generar ticket.
- Limpiar carrito después de una venta correcta.

El carrito debe conservar los productos al actualizar la página si esa opción
está activada.

El botón Pagar debe funcionar siempre que:

- Existan productos.
- La caja esté abierta.
- Los datos del pago sean válidos.

Cuando no pueda continuar debe explicar la razón.

Ejemplos:

- “Abre la caja antes de registrar ventas.”
- “El efectivo recibido es menor al total.”
- “Ingresa el número de operación.”
- “Selecciona un cliente.”
- “El producto no tiene stock suficiente.”

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
11. MÉTODOS DE PAGO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Métodos disponibles:

- Efectivo.
- Yape.
- Plin.
- Transferencia.
- Crédito.
- Pago mixto.

PAGO EN EFECTIVO

Debe asumir monto exacto inicialmente.

Debe mostrar montos rápidos válidos según el total.

Billetes disponibles:

- S/10
- S/20
- S/50
- S/100
- S/200

Regla:

Solo mostrar billetes cuyo valor sea igual o superior al total.

Ejemplo:

Total S/29.50:
- S/50
- S/100
- S/200

Total S/15.20:
- S/20
- S/50
- S/100
- S/200

Total superior a S/100:
- S/200, siempre que cubra el total.

Nunca mostrar un monto rápido inferior al total.

Los botones deben establecer el monto, no sumarlo repetidamente.

Ejemplo incorrecto:
Total + 20 + 100.

Ejemplo correcto:
Al tocar S/20, monto recibido = S/20.
Al tocar S/100, monto recibido = S/100.

Debe existir:

- Monto exacto.
- Otros montos.
- Cálculo de vuelto.

PAGO DIGITAL

Debe pedir:

- Método.
- Número de operación.

El número de operación debe validarse.

No permitir operaciones digitales duplicadas.

PAGO MIXTO

Debe permitir:

- Una parte en efectivo.
- El saldo mediante Yape, Plin o transferencia.

Ejemplo:

Total: S/75
Efectivo: S/20
Digital: S/55

Debe calcular automáticamente el saldo digital.

En caja:

- Solo S/20 se registran como efectivo.
- S/55 se registran como digital.

El ticket debe mostrar ambos pagos.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
12. PRODUCTOS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

“Nuevo producto” y “Editar producto” deben compartir:

- El mismo HTML.
- El mismo CSS.
- Las mismas validaciones.
- La misma distribución.
- Los mismos campos.

Solo debe cambiar:

- El título.
- Los datos cargados.
- La acción Guardar.
- Si se crea o actualiza.

Orden principal requerido:

1. Nombre.
2. SKU y código de barras.
3. Categoría, botón Nueva e icono.
4. Imagen del producto.
5. Costo y precio de venta.
6. Margen de ganancia.
7. Stock inicial y stock mínimo.
8. Precio por caja y unidades por caja.
9. Fecha de vencimiento.
10. Opciones avanzadas.
11. Cancelar y Guardar.

Campos principales:

- Nombre.
- SKU.
- Código de barras principal.
- Categoría.
- Icono.
- Imagen.
- Costo.
- Precio de venta.
- Margen.
- Stock inicial.
- Stock mínimo.
- Precio por caja.
- Unidades por caja.
- Fecha de vencimiento.

Opciones avanzadas:

- Descripción.
- Marca.
- Unidad de medida.
- Código alternativo.
- Códigos de barras alternativos.
- Incluye IGV.
- Tipo de impuesto.
- Impuesto complementario.
- Control de inventario.
- Tienda.

UNIDADES DE MEDIDA

- Unidad.
- Paquete.
- Caja.
- Botella.
- Lata.
- Bolsa.
- Kilogramo.
- Gramo.
- Litro.
- Mililitro.
- Docena.
- Rollo.
- Servicio.
- Otro.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
13. CÓDIGOS DE BARRAS ALTERNATIVOS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cada producto debe tener:

- Un código de barras principal.
- Hasta diez códigos de barras alternativos.

Debe existir un botón:

“Añadir otro código de barras”

Debe funcionar realmente.

Al presionarlo:

1. Crear una fila nueva.
2. Mantenerla visible aunque esté vacía.
3. Enfocar el nuevo campo.
4. Actualizar contador.
5. Permitir eliminar la fila.
6. No superar diez códigos.

Contador:

- 0/10.
- 1/10.
- 2/10.
- Hasta 10/10.

Validaciones:

- No aceptar códigos duplicados en el mismo producto.
- No aceptar un código usado por otro producto.
- No aceptar el código principal como alternativo.
- Eliminar espacios innecesarios.
- No guardar filas vacías.
- Conservar códigos al editar.
- Conservar códigos al recargar.

El buscador y el escáner deben reconocer:

- SKU.
- Código principal.
- Los diez códigos alternativos.

La fila vacía no debe eliminarse automáticamente inmediatamente después de
presionar “Añadir”.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
14. CATEGORÍAS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Categorías base:

- Abarrotes.
- Bebidas.
- Snacks.
- Helados.
- Licores.
- Limpieza.
- Cuidado personal.
- Bebés.
- Hogar y bazar.
- Tecnología.
- Librería.
- Servicios.
- Accesorios.

El sistema debe permitir:

- Agregar categoría al crear producto.
- Mostrar todas las categorías en teléfono.
- Mostrar todas las categorías en computadora.
- Guardar categorías nuevas.
- Conservarlas después de recargar.
- Usarlas en filtros.
- Usarlas en el POS.
- Usarlas en inventario.
- Reclasificar catálogo.

La clasificación automática debe analizar el nombre del producto.

No debe enviar productos diferentes a una categoría incorrecta por utilizar
reglas demasiado generales.

La categoría visible debe mostrar un nombre comprensible, no claves técnicas.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
15. INVENTARIO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El módulo debe mostrar:

- Total de productos.
- Stock crítico.
- Productos por vencer.
- Productos vencidos.
- Costo total del inventario.
- Valor total de venta.
- Ganancia potencial.

Cálculos:

Costo del inventario:
Suma de costo × stock.

Valor total de venta:
Suma de precio de venta × stock.

Ganancia potencial:
Valor de venta - costo del inventario.

Debe mostrar:

- Nombre.
- SKU.
- Categoría.
- Costo.
- Precio.
- Stock.
- Estado.
- Acciones.

Funciones:

- Editar producto.
- Registrar entrada.
- Registrar salida.
- Ajustar stock.
- Buscar.
- Filtrar por categoría.
- Filtrar por stock crítico.
- Filtrar por vencimiento.
- Reclasificar catálogo.
- Importar productos.
- Exportar productos.

Control de inventario:

Si está activado:

- Descontar stock.
- Mostrar alertas.
- Bloquear venta sin existencias.
- Incluir en stock crítico.

Si está desactivado:

- Permitir ventas sin stock.
- No bloquear producto.
- No incluirlo en alertas críticas.
- No descontar existencias.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
16. VENTAS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cada venta debe guardar:

- ID.
- Número de ticket.
- Fecha.
- Hora.
- Cajero.
- Productos.
- Cantidades.
- Precio unitario.
- Importes.
- Total.
- Método de pago.
- Monto recibido.
- Vuelto.
- Número de operación.
- Cliente.
- Pago mixto.
- Parte en efectivo.
- Parte digital.
- Estado.
- Si fue anulada.
- Motivo de anulación.

Al confirmar:

1. Validar pago.
2. Crear la venta.
3. Descontar stock.
4. Registrar caja.
5. Guardar datos.
6. Limpiar carrito.
7. Mostrar confirmación.
8. Generar ticket.
9. Imprimir si está habilitado.

Una falla del ticket no debe anular la venta.

Una falla de impresión no debe borrar la venta.

Debe existir historial y filtros:

- Por fecha.
- Por método.
- Por cliente.
- Por número de ticket.
- Por número de operación.
- Por estado.
- Por cajero.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
17. CLIENTES Y CRÉDITOS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Clientes:

- Nombre.
- DNI o RUC.
- Teléfono.
- Dirección.
- Historial.
- Créditos.
- Saldo pendiente.

Créditos:

- Cliente.
- Descripción.
- Monto.
- Pagado.
- Saldo.
- Fecha.
- Fecha de vencimiento.
- Estado.
- Pagos realizados.

Estados:

- Activo.
- Parcial.
- Cancelado.
- Vencido.
- Anulado.

Registrar abonos con:

- Monto.
- Método de pago.
- Fecha.
- Número de operación cuando corresponda.

Actualizar automáticamente el saldo.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
18. CAJA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

La caja debe tener:

- Apertura.
- Fondo inicial.
- Cajero.
- Fecha.
- Hora.
- Ingresos.
- Egresos.
- Ventas en efectivo.
- Ventas digitales.
- Créditos cobrados.
- Gastos.
- Retiros.
- Cierre.
- Diferencia.

No permitir ventas si la caja no está abierta, salvo que exista una configuración
explícita que lo autorice.

Al cerrar:

- Mostrar efectivo esperado.
- Solicitar efectivo contado.
- Calcular diferencia.
- Registrar sobrante o faltante.
- Solicitar autorización si está protegido.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
19. GASTOS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Debe permitir registrar:

- Concepto.
- Categoría.
- Monto.
- Método.
- Fecha.
- Hora.
- Usuario.
- Nota.

Los gastos en efectivo deben afectar la caja.

Los gastos digitales deben registrarse sin alterar el efectivo físico.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
20. TICKET TÉRMICO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El ticket debe ser completamente blanco y negro.

No utilizar colores en impresión.

Utilizar:

- Texto negro.
- Fondo blanco.
- Líneas.
- Separadores.
- Negritas.
- Recuadros.
- Tipografía monoespaciada.

Evitar emojis en el ticket, porque muchas impresoras no los reconocen.

Anchos:

- 30 mm.
- 40 mm.
- 50 mm.
- 58 mm.
- 80 mm.
- Personalizado.

El contenido debe adaptarse según el ancho.

En 30–40 mm:

- Abreviar etiquetas.
- Usar varias líneas.
- Ocultar columnas que no caben.
- Mostrar importes claramente.

En 50–58 mm:

- Usar formato compacto.
- Mantener cantidad, descripción e importe.

En 80 mm:

- Mostrar estructura completa.

Opciones:

- Mostrar u ocultar S/.
- Mostrar u ocultar precio unitario.
- Mostrar u ocultar operación.
- Mostrar u ocultar recibido.
- Mostrar u ocultar vuelto.
- Mostrar u ocultar forma de pago.
- Mostrar u ocultar IGV.
- Mostrar separadores.
- Alineación del negocio.
- Alineación de datos generales.
- Alineación de totales.
- Alineación de mensaje final.

Tamaño de vista previa independiente de la impresión:

- 9 px.
- 10 px.
- 11 px.
- 12 px.
- 13 px.
- 15 px.
- Personalizado.

Estructura:

MULTISERVICIOS
NUEVO AMANECER

Puerto Súngaro - Huánuco

Ticket N°: V-000001
Fecha:
Hora:
Cajero:

Cant. Descripción Importe

Productos

Total de artículos:
TOTAL:
Forma de pago:
Recibido:
Vuelto:

Mensaje final.

La cantidad no debe repetirse.

Incorrecto:
2 en columna y nuevamente “2 × S/7”.

Correcto:
2 Arroz S/14
P.U. S/7

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
21. IMPRESIÓN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Métodos:

- Impresión del sistema.
- Aplicación de impresión térmica.
- Bluetooth mediante aplicación.
- USB/OTG cuando el navegador lo permita.
- Web Serial cuando el dispositivo sea compatible.

Una página HTML no puede enumerar libremente todos los dispositivos Bluetooth
Classic vinculados como una aplicación Android nativa.

No prometer funciones imposibles desde el navegador.

Mostrar estados claros:

- Bluetooth activado.
- Dispositivo autorizado.
- Dispositivo conectado.
- No compatible.
- Permiso denegado.
- Requiere aplicación.
- Requiere HTTPS.
- Requiere USB/OTG.

No mostrar mensajes técnicos crudos como “Permission denied”.

Traducirlos:

“No fue posible acceder al dispositivo. Verifica los permisos de Bluetooth,
dispositivos cercanos o utiliza la aplicación de impresión.”

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
22. CONFIGURACIÓN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Secciones:

- Negocio.
- Punto de Venta.
- Apariencia.
- Ticket.
- Control maestro.
- Reseteo.
- Importar datos.
- Sistema.

En teléfono:

- Mostrar una sección a la vez.
- Ocultar menú después de elegir.
- Botón de tres rayas para abrir menú.
- Permitir volver a otra sección.

No repetir títulos como:

- Configuración del sistema.
- Estado del sistema.
- Centro de configuración.

Debe existir un único encabezado claro.

NEGOCIO

- Nombre comercial.
- RUC o DNI.
- Teléfono.
- Dirección.
- Cajero predeterminado.
- Tienda.

PUNTO DE VENTA

- Mayorista.
- Control de margen.
- Stock mínimo.
- Persistencia de carrito.
- Reclasificación.
- Reglas de pago.

APARIENCIA

- Tema.
- Fuente.
- Tamaño.
- Color principal.
- Modo claro u oscuro.
- Densidad visual.

TICKET

- Ancho.
- Fuente.
- Tamaño.
- Alineación.
- Campos visibles.
- Mensaje final.
- Impresión automática.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
23. CONTROL MAESTRO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Debe funcionar como centro real de seguridad.

Funciones:

- PIN maestro.
- Cambiar PIN.
- Desactivar PIN.
- Bloqueo inmediato.
- Bloqueo automático.
- Tiempo de inactividad.
- Modo solo lectura.
- Bloqueo de productos.
- Bloqueo de ventas.
- Bloqueo de caja.
- Bloqueo de clientes.
- Bloqueo de gastos.
- Bloqueo de configuración.
- Bloqueo de importaciones.
- Autorización de descuentos.
- Límite máximo de descuento.
- Autorización para anular ventas.
- Autorización para cerrar caja.
- Autorización para resetear.
- Registro de seguridad.

Historial:

- Intentos incorrectos.
- Cambios de configuración.
- Desbloqueos.
- Anulaciones.
- Reseteos.
- Importaciones.
- Cierres.
- Cambios de PIN.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
24. AVISOS Y CONFIRMACIONES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Usar avisos propios del sistema.

La configuración debe permitir:

“Avisos de confirmación: activado/desactivado”.

Al desactivar:

- Limpiar carrito puede ejecutarse sin aviso.
- Acciones normales pueden omitir confirmación.

Sin embargo, las operaciones críticas siempre deben solicitar confirmación:

- Restablecer sistema.
- Borrar ventas.
- Borrar productos.
- Borrar caja.
- Borrar clientes.
- Restaurar respaldo.
- Eliminar toda la información.

El reseteo siempre debe solicitar:

1. Aviso.
2. PIN o clave.
3. Confirmación final.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
25. ALMACENAMIENTO Y PERSISTENCIA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Los datos deben mantenerse después de actualizar.

No depender únicamente de variables en memoria.

Utilizar una estrategia estable:

- IndexedDB como almacenamiento principal.
- localStorage para configuración pequeña.
- sessionStorage únicamente como respaldo temporal.
- Exportación JSON para respaldo.
- Migraciones de esquema.

Debe existir versión del esquema:

databaseVersion: 1

Cuando cambie la estructura:

- Migrar datos.
- No borrar datos antiguos.
- Completar campos faltantes con valores predeterminados.
- Validar datos.
- Crear respaldo previo.

Datos persistentes:

- Productos.
- Categorías.
- Ventas.
- Clientes.
- Créditos.
- Caja.
- Gastos.
- Configuración.
- Seguridad.
- Carrito.
- Códigos alternativos.
- Contadores.
- Ticket.

No afirmar que existe sincronización entre teléfonos si no existe servidor o
nube.

La persistencia local funciona únicamente en el mismo navegador y dispositivo.

Para varios dispositivos se necesita:

- Base de datos remota.
- Cuenta de usuario.
- Autenticación.
- Sincronización.
- Control de conflictos.
- Copias de seguridad.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
26. IMPORTACIÓN, EXPORTACIÓN Y RESPALDOS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Formatos:

- JSON.
- CSV.
- Excel cuando corresponda.

Debe permitir:

- Exportar catálogo.
- Importar catálogo.
- Exportar ventas.
- Exportar clientes.
- Exportar créditos.
- Crear respaldo completo.
- Restaurar respaldo.
- Validar respaldo.
- Mostrar fecha.
- Mostrar cantidad de registros.
- Evitar sobrescribir datos sin confirmación.

El catálogo actual contiene aproximadamente 408 productos.

La importación debe:

- Validar nombre.
- Validar precio.
- Validar SKU.
- Validar código de barras.
- Evitar duplicados.
- Clasificar categorías.
- Informar filas omitidas.
- Informar filas actualizadas.
- Informar productos nuevos.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
27. MANEJO DE ERRORES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Nunca mostrar únicamente:

“Error al guardar”.

Mostrar una causa comprensible:

- No hay espacio disponible.
- El navegador bloqueó almacenamiento.
- Existe un código duplicado.
- Falta abrir caja.
- El número de operación ya fue usado.
- El precio es menor al costo.
- El archivo no tiene formato válido.
- No se pudo abrir la impresora.
- El dispositivo no es compatible.

Los errores deben registrarse en consola con información técnica.

Ejemplo:

console.error("[Productos] Error guardando producto", error);

Pero al usuario se le muestra:

“No se pudo guardar el producto. Revisa el almacenamiento del navegador.”

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
