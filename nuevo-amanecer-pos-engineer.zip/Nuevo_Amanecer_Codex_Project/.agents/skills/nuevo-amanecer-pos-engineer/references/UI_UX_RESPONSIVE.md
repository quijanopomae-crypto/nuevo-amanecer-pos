# UI, UX y responsive — Nuevo Amanecer

## Identidad visual

- Verde esmeralda como color principal.
- Diseño comercial, moderno, profesional y claro.
- Evitar exceso de minimalismo, sombras, degradados, iconos y tarjetas gigantes.
- No repetir información ni accesos.
- El ticket no hereda colores del sistema.

## Referencias visuales

Cuando una captura sea exacta:

1. Respetar orden.
2. Respetar columnas.
3. Mantener campos agrupados.
4. Mantener tamaños relativos.
5. Mostrar únicamente lo solicitado.
6. Conservar opciones secundarias en Opciones avanzadas.
7. Comparar el resultado con la referencia.

Organizar no significa rediseñar. Compactar no significa eliminar.

## Resoluciones obligatorias

- 320 px.
- 360 px.
- 390 px.
- 430 px.
- 768 px.
- 1024 px.
- 1366 px.
- 1920 px.

## Teléfono

- Sin cortes.
- Sin desplazamiento horizontal innecesario.
- Scroll vertical fluido.
- Modales accesibles.
- Teclado no bloquea Guardar.
- Botones cómodos.
- Menú de configuración con tres rayas.
- Productos normalmente en dos columnas.
- Campos cortos pueden mantener dos columnas: SKU/código, costo/precio, stock/mínimo, caja/unidades.

## Computadora

- Aprovechar ancho.
- Evitar espacios vacíos excesivos.
- No estirar inputs sin necesidad.
- Mantener jerarquía clara.

## Formulario de producto

Nueva y Editar comparten componente.

Orden:

1. Nombre.
2. SKU | Código principal.
3. Categoría + Nueva | Icono.
4. Imagen.
5. Costo | Precio.
6. Margen.
7. Stock | Mínimo.
8. Precio caja | Unidades.
9. Vencimiento.
10. Opciones avanzadas.
11. Cancelar | Guardar.

## Modales

- Encabezado claro.
- Scroll correcto.
- No usar `overflow:hidden` de forma que bloquee.
- Acciones accesibles.
- Campos obligatorios visibles.
- Overlays no deben interceptar clics.

## Accesibilidad básica

- Etiquetas visibles.
- Foco visible.
- Botones semánticos.
- `type="button"` para acciones que no envían formularios.
- Contraste suficiente.
- No depender solo del color.
- `inputmode` apropiado.
