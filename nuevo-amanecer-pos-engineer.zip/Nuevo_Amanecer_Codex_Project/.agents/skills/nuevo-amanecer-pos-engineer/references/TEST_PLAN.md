# Plan de pruebas obligatorio

28. PRUEBAS OBLIGATORIAS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Antes de entregar una corrección, probar:

PRODUCTOS

- Crear producto.
- Editar producto.
- Crear categoría.
- Añadir imagen.
- Añadir código principal.
- Añadir diez códigos alternativos.
- Intentar añadir el código número once.
- Eliminar un código alternativo.
- Detectar código duplicado.
- Guardar.
- Recargar.
- Confirmar persistencia.

INVENTARIO

- Entrada.
- Salida.
- Stock mínimo.
- Producto sin inventario.
- Producto vencido.
- Filtro.
- Ganancia potencial.

POS

- Agregar productos.
- Cambiar cantidad.
- Limpiar carrito.
- Recargar.
- Cobrar.
- Descontar stock.

PAGOS

- Efectivo exacto.
- Efectivo mayor.
- Efectivo insuficiente.
- Yape.
- Transferencia.
- Crédito.
- Pago mixto.
- Operación duplicada.

VENTAS

- Registrar venta.
- Abrir ticket.
- Reimprimir.
- Anular.
- Ver historial.

CAJA

- Abrir.
- Registrar venta.
- Registrar gasto.
- Cerrar.
- Calcular diferencia.

CONFIGURACIÓN

- Desactivar función.
- Recargar.
- Confirmar que permanezca desactivada.
- Cambiar apariencia.
- Cambiar ticket.
- Probar PIN.

RESPONSIVE

- Teléfono vertical.
- Teléfono horizontal.
- Tablet.
- Computadora.
- Scroll.
- Teclado.
- Modal.
- Botones.

IMPRESIÓN

- Vista previa.
- 30 mm.
- 40 mm.
- 50 mm.
- 58 mm.
- 80 mm.
- Sin elementos cortados.
- Sin cantidad repetida.
- Blanco y negro.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
