# Flujo de trabajo, prohibiciones, definición de terminado y primera auditoría

## Regla de interpretación

La sección original que indica “no modificar hasta recibir autorización” se aplica cuando la tarea es solo de diagnóstico. Cuando el propietario ordene expresamente “audita y parchea”, Codex puede corregir hallazgos críticos y altos bajo las restricciones de AGENTS.md.

29. FLUJO DE TRABAJO OBLIGATORIO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Para cada solicitud:

PASO 1: ANALIZAR

- Identificar archivo base.
- Identificar módulo.
- Identificar función.
- Identificar CSS.
- Identificar datos.
- Identificar riesgos.

PASO 2: EXPLICAR

Antes de modificar, indicar brevemente:

- Qué error se encontró.
- Por qué ocurre.
- Qué se modificará.
- Qué no se tocará.

PASO 3: RESPALDAR

- Crear commit o copia.
- Registrar estado estable.

PASO 4: IMPLEMENTAR

- Realizar cambio mínimo.
- No modificar módulos no relacionados.
- No duplicar funciones.
- No añadir IDs repetidos.

PASO 5: PROBAR

- Ejecutar caso solicitado.
- Ejecutar casos relacionados.
- Revisar consola.
- Revisar teléfono.
- Revisar computadora.

PASO 6: ENTREGAR

Informar:

- Error encontrado.
- Solución.
- Archivos modificados.
- Funciones probadas.
- Limitaciones.
- Pendientes reales.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
30. PROHIBICIONES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Está prohibido:

- Usar una versión antigua sin avisar.
- Rehacer todo el sistema por una corrección pequeña.
- Agregar funciones visuales no solicitadas.
- Eliminar datos para solucionar un error.
- Ocultar errores.
- Desactivar validaciones sin justificación.
- Crear IDs HTML duplicados.
- Definir funciones con el mismo nombre varias veces.
- Sobrescribir funciones accidentalmente.
- Usar confirmaciones nativas.
- Bloquear el scroll.
- Dejar un modal sin botón accesible.
- Mostrar colores en ticket térmico.
- Inventar que Bluetooth es compatible cuando no lo es.
- Prometer sincronización sin backend.
- Decir “corregido” sin comprobar.
- Cambiar el diseño exacto de una referencia por una interpretación propia.
- Mezclar versiones.
- Generar un bucle de cambios contradictorios.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
31. DEFINICIÓN DE “TERMINADO”
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Una tarea solo está terminada cuando:

- La función solicitada existe.
- El botón funciona.
- Los datos se guardan.
- Los datos sobreviven a recarga.
- No aparecen errores en consola.
- No se rompieron otros módulos.
- Funciona en teléfono.
- Funciona en computadora.
- El diseño coincide con la solicitud.
- Los campos no están cortados.
- El scroll funciona.
- Las validaciones funcionan.
- Se informa claramente lo realizado.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
32. VISIÓN FUTURA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

El sistema debe prepararse para evolucionar hacia:

- Aplicación PWA instalable.
- APK Android.
- Sincronización en la nube.
- Usuarios y permisos.
- Varias tiendas.
- Varias cajas.
- Base de datos central.
- Panel remoto.
- Control por sucursal.
- Proveedores.
- Compras.
- Órdenes de compra.
- Facturación electrónica.
- Boleta electrónica.
- Integración SUNAT.
- Lectura de códigos mediante cámara.
- Impresión Bluetooth nativa.
- Reportes avanzados.
- Gráficos.
- Ganancia real.
- Flujo de caja.
- Alertas de vencimiento.
- Copias automáticas.
- Auditoría.
- Panel administrativo.

Estas funciones futuras no deben implementarse sin planificación.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
33. FORMATO DE RESPUESTA DEL PROGRAMADOR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cuando se solicite una corrección, responder con este formato:

DIAGNÓSTICO

Explicar el error exacto y su causa.

ALCANCE

Indicar qué módulo se modificará y cuáles no.

IMPLEMENTACIÓN

Explicar los cambios realizados.

PRUEBAS

Indicar las pruebas realmente ejecutadas.

RESULTADO

Indicar el resultado real.

PENDIENTES

Indicar cualquier limitación o riesgo que continúe.

No utilizar frases genéricas como:

- “Ya está todo solucionado.”
- “Funciona perfectamente.”
- “Se probó todo.”

Solo afirmarlo cuando exista evidencia.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
34. PRIMERA TAREA AL RECIBIR EL ARCHIVO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Antes de hacer nuevas modificaciones:

Analiza completamente el archivo principal sin modificarlo.

Busca:

- Errores JavaScript.
- IDs duplicados.
- Funciones duplicadas.
- Variables duplicadas.
- Eventos que no funcionan.
- Configuraciones que no persisten.
- Productos que desaparecen.
- Errores de almacenamiento.
- Problemas de scroll.
- Problemas responsive.
- Botones sin función.
- Errores de ventas.
- Errores de pagos.
- Errores de inventario.
- Errores de ticket.
- Errores de impresión.
- Código antiguo no utilizado.
- CSS contradictorio.
- Reglas responsive contradictorias.
- Funciones sobrescritas.
- Datos sin migración.

Entregar un informe con:

1. Errores críticos.
2. Errores importantes.
3. Errores visuales.
4. Código duplicado.
5. Riesgos de pérdida de datos.
6. Problemas responsive.
7. Problemas de arquitectura.
8. Recomendaciones.
9. Orden recomendado de corrección.

No modificar ningún archivo hasta recibir autorización.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FIN DE LAS INSTRUCCIONES DEL PROYECTO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
