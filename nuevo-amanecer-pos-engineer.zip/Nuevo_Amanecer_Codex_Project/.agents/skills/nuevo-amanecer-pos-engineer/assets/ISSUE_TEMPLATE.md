# Diagnóstico de error — Nuevo Amanecer

## Identificación

- ID:
- Fecha:
- Archivo/commit:
- Módulo:
- Severidad:

## Problema

- Acción exacta:
- Resultado esperado:
- Resultado obtenido:
- Frecuencia:
- Datos utilizados:

## Entorno

- Dispositivo:
- Sistema operativo:
- Navegador:
- Tamaño de pantalla:
- file://, servidor local o PWA:
- Caché:
- Permisos:

## Evidencia

- Consola:
- Captura/video:
- Datos:
- Diff relacionado:

## Hipótesis

- Categoría:
- Hipótesis:
- Evidencia a favor:
- Evidencia en contra:
- Experimento:
- Resultado:
- Estado:

## Causa raíz y cinco porqués

1.
2.
3.
4.
5.

## Corrección

- Cambio:
- Archivos:
- Funciones:
- Datos/migración:
- Riesgos:

## Pruebas

- Principal:
- Casos límite:
- Persistencia:
- Regresión:
- Teléfono:
- Computadora:
- Consola:

## Prevención

- Patrón repetitivo:
- Cambio de proceso:
- Prueba preventiva:
- Criterio de cierre:
