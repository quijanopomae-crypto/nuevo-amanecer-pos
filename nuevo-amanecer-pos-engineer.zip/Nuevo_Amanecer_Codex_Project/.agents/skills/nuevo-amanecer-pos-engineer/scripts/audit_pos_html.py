#!/usr/bin/env python3
"""Static audit helper for the Nuevo Amanecer single-file POS.

This script intentionally uses only Python's standard library. It does not prove
that a finding is exploitable or a bug; it helps Codex locate high-risk areas
before a manual review and browser test.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Finding:
    severity: str
    category: str
    code: str
    message: str
    line: int | None = None
    evidence: str | None = None


SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def excerpt(text: str, start: int, length: int = 140) -> str:
    value = text[start : start + length].splitlines()[0].strip()
    return value[:140]


def duplicate_occurrences(pattern: re.Pattern[str], text: str) -> dict[str, list[int]]:
    found: dict[str, list[int]] = defaultdict(list)
    for match in pattern.finditer(text):
        found[match.group(1)].append(line_number(text, match.start()))
    return {name: lines for name, lines in found.items() if len(lines) > 1}


def audit_html(path: Path) -> tuple[list[Finding], dict[str, object]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    findings: list[Finding] = []

    # Duplicate DOM IDs.
    id_pattern = re.compile(r'\bid\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
    duplicate_ids = duplicate_occurrences(id_pattern, text)
    for value, lines in duplicate_ids.items():
        findings.append(
            Finding(
                "high",
                "DOM",
                "DOM-DUPLICATE-ID",
                f"El id '{value}' aparece {len(lines)} veces.",
                lines[0],
                f"Líneas: {', '.join(map(str, lines[:12]))}",
            )
        )

    # Duplicate classic function declarations.
    fn_pattern = re.compile(
        r"(?:^|[;{}\n])\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(",
        re.MULTILINE,
    )
    duplicate_functions = duplicate_occurrences(fn_pattern, text)
    for value, lines in duplicate_functions.items():
        findings.append(
            Finding(
                "high",
                "JavaScript",
                "JS-DUPLICATE-FUNCTION",
                f"La función '{value}' está declarada {len(lines)} veces y una versión puede sobrescribir a otra.",
                lines[0],
                f"Líneas: {', '.join(map(str, lines[:12]))}",
            )
        )

    # Duplicate top-level-ish const/let declarations (heuristic).
    var_pattern = re.compile(
        r"^[ \t]*(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=",
        re.MULTILINE,
    )
    duplicate_vars = duplicate_occurrences(var_pattern, text)
    for value, lines in duplicate_vars.items():
        findings.append(
            Finding(
                "medium",
                "JavaScript",
                "JS-DUPLICATE-BINDING",
                f"La variable '{value}' aparece declarada varias veces; confirmar alcance y posible conflicto.",
                lines[0],
                f"Líneas: {', '.join(map(str, lines[:12]))}",
            )
        )

    # Risky DOM sinks.
    sink_patterns = {
        "innerHTML": re.compile(r"\.innerHTML\s*=", re.IGNORECASE),
        "outerHTML": re.compile(r"\.outerHTML\s*=", re.IGNORECASE),
        "insertAdjacentHTML": re.compile(r"\.insertAdjacentHTML\s*\(", re.IGNORECASE),
        "document.write": re.compile(r"document\.write\s*\(", re.IGNORECASE),
    }
    for sink, pattern in sink_patterns.items():
        for match in pattern.finditer(text):
            findings.append(
                Finding(
                    "medium" if sink != "document.write" else "high",
                    "Security",
                    "SEC-RISKY-DOM-SINK",
                    f"Uso de {sink}; revisar si incorpora datos de usuario o importados sin sanitización.",
                    line_number(text, match.start()),
                    excerpt(text, match.start()),
                )
            )

    # Native dialogs conflict with project rules and can block flows.
    dialog_pattern = re.compile(r"\b(alert|confirm|prompt)\s*\(")
    for match in dialog_pattern.finditer(text):
        findings.append(
            Finding(
                "low",
                "UX",
                "UX-NATIVE-DIALOG",
                f"Uso de {match.group(1)}(); el proyecto exige modales propios.",
                line_number(text, match.start()),
                excerpt(text, match.start()),
            )
        )

    # Buttons without explicit type.
    button_pattern = re.compile(r"<button\b([^>]*)>", re.IGNORECASE | re.DOTALL)
    for match in button_pattern.finditer(text):
        attrs = match.group(1)
        if not re.search(r"\btype\s*=", attrs, re.IGNORECASE):
            findings.append(
                Finding(
                    "low",
                    "DOM",
                    "DOM-BUTTON-NO-TYPE",
                    "Botón sin type explícito; dentro de un formulario puede ejecutar submit accidentalmente.",
                    line_number(text, match.start()),
                    re.sub(r"\s+", " ", match.group(0))[:140],
                )
            )

    # Inline event handler targets and missing named functions (heuristic).
    inline_handler = re.compile(
        r"\bon(?:click|change|input|submit|touchstart|pointerdown)\s*=\s*[\"\']\s*([A-Za-z_$][\w$]*)\s*\(",
        re.IGNORECASE,
    )
    declared_functions = set(fn_pattern.findall(text))
    declared_functions.update(
        re.findall(
            r"(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>",
            text,
        )
    )
    browser_builtins = {"print", "open", "close", "focus", "blur", "scrollTo"}
    for match in inline_handler.finditer(text):
        fn_name = match.group(1)
        if fn_name not in declared_functions and fn_name not in browser_builtins:
            findings.append(
                Finding(
                    "high",
                    "Events",
                    "EVENT-MISSING-HANDLER",
                    f"El manejador inline llama a '{fn_name}()', pero no se encontró una declaración compatible.",
                    line_number(text, match.start()),
                    excerpt(text, match.start()),
                )
            )

    # Duplicate event registration sites (informational heuristic).
    event_reg_pattern = re.compile(
        r"getElementById\(\s*[\"\']([^\"\']+)[\"\']\s*\)\s*\.addEventListener\(\s*[\"\']([^\"\']+)[\"\']",
        re.IGNORECASE,
    )
    event_pairs: dict[tuple[str, str], list[int]] = defaultdict(list)
    for match in event_reg_pattern.finditer(text):
        event_pairs[(match.group(1), match.group(2))].append(line_number(text, match.start()))
    for (element_id, event_name), lines in event_pairs.items():
        if len(lines) > 1:
            findings.append(
                Finding(
                    "medium",
                    "Events",
                    "EVENT-DUPLICATE-REGISTRATION",
                    f"El evento '{event_name}' se registra varias veces sobre '#{element_id}'; revisar doble ejecución.",
                    lines[0],
                    f"Líneas: {', '.join(map(str, lines[:12]))}",
                )
            )

    # Storage keys inventory and suspicious JSON.parse without local try (informational).
    storage_key_pattern = re.compile(
        r"(?:localStorage|sessionStorage)\.(?:getItem|setItem|removeItem)\(\s*[\"\']([^\"\']+)[\"\']",
        re.IGNORECASE,
    )
    storage_keys = sorted(set(storage_key_pattern.findall(text)))

    json_parse_pattern = re.compile(r"JSON\.parse\s*\(")
    for match in json_parse_pattern.finditer(text):
        window = text[max(0, match.start() - 260) : match.start()]
        if "try" not in window:
            findings.append(
                Finding(
                    "medium",
                    "Storage",
                    "STORAGE-UNGUARDED-JSON-PARSE",
                    "JSON.parse sin un try cercano; datos corruptos pueden bloquear la carga.",
                    line_number(text, match.start()),
                    excerpt(text, match.start()),
                )
            )

    # Potential non-idempotent sale/confirm buttons based on terms.
    confirm_handlers = re.finditer(
        r"(?:function\s+|const\s+|let\s+|var\s+)([A-Za-z_$][\w$]*(?:venta|sale|pago|payment|confirm)[A-Za-z_$\w]*)",
        text,
        re.IGNORECASE,
    )
    critical_handler_names = sorted(set(m.group(1) for m in confirm_handlers))

    # CSS flags.
    important_count = len(re.findall(r"!important\b", text, re.IGNORECASE))
    overflow_hidden_count = len(re.findall(r"overflow(?:-y|-x)?\s*:\s*hidden", text, re.IGNORECASE))
    media_query_count = len(re.findall(r"@media\b", text, re.IGNORECASE))
    pointer_none_count = len(re.findall(r"pointer-events\s*:\s*none", text, re.IGNORECASE))
    if important_count >= 20:
        findings.append(
            Finding(
                "medium",
                "CSS",
                "CSS-MANY-IMPORTANT",
                f"Se detectaron {important_count} usos de !important; pueden bloquear correcciones y crear reglas contradictorias.",
            )
        )
    if overflow_hidden_count:
        findings.append(
            Finding(
                "info",
                "CSS",
                "CSS-OVERFLOW-HIDDEN",
                f"Se detectaron {overflow_hidden_count} reglas overflow:hidden; revisar modales y scroll móvil.",
            )
        )
    if pointer_none_count:
        findings.append(
            Finding(
                "info",
                "CSS",
                "CSS-POINTER-EVENTS-NONE",
                f"Se detectaron {pointer_none_count} reglas pointer-events:none; verificar áreas táctiles y overlays.",
            )
        )

    summary: dict[str, object] = {
        "file": str(path),
        "bytes": path.stat().st_size,
        "lines": text.count("\n") + 1,
        "duplicate_ids": duplicate_ids,
        "duplicate_functions": duplicate_functions,
        "duplicate_bindings": duplicate_vars,
        "storage_keys": storage_keys,
        "critical_handler_candidates": critical_handler_names,
        "css": {
            "important_count": important_count,
            "overflow_hidden_count": overflow_hidden_count,
            "media_query_count": media_query_count,
            "pointer_events_none_count": pointer_none_count,
        },
    }

    findings.sort(
        key=lambda item: (
            SEVERITY_ORDER.get(item.severity, 99),
            item.line if item.line is not None else 10**9,
            item.code,
        )
    )
    return findings, summary


def render_markdown(findings: Iterable[Finding], summary: dict[str, object]) -> str:
    items = list(findings)
    counts = Counter(item.severity for item in items)
    lines = [
        "# Auditoría estática preliminar",
        "",
        f"- Archivo: `{summary['file']}`",
        f"- Líneas: {summary['lines']}",
        f"- Tamaño: {summary['bytes']} bytes",
        f"- Hallazgos: {len(items)}",
        "- Aviso: cada hallazgo debe confirmarse manualmente y mediante pruebas en navegador.",
        "",
        "## Resumen por severidad",
        "",
    ]
    for severity in ("critical", "high", "medium", "low", "info"):
        lines.append(f"- {severity}: {counts.get(severity, 0)}")

    lines.extend(["", "## Hallazgos", ""])
    if not items:
        lines.append("No se detectaron hallazgos mediante estas reglas estáticas.")
    for index, item in enumerate(items, 1):
        location = f" — línea {item.line}" if item.line else ""
        lines.extend(
            [
                f"### {index}. [{item.severity.upper()}] {item.code}{location}",
                "",
                f"- Categoría: {item.category}",
                f"- Descripción: {item.message}",
            ]
        )
        if item.evidence:
            lines.append(f"- Evidencia: `{item.evidence}`")
        lines.append("")

    lines.extend(["## Inventario técnico", ""])
    storage_keys = summary.get("storage_keys", [])
    lines.append(f"- Claves local/session storage: {len(storage_keys)}")
    for key in storage_keys:
        lines.append(f"  - `{key}`")
    css = summary.get("css", {})
    lines.append(f"- Media queries: {css.get('media_query_count', 0)}")
    lines.append(f"- !important: {css.get('important_count', 0)}")
    lines.append(f"- overflow:hidden: {css.get('overflow_hidden_count', 0)}")
    lines.append(f"- pointer-events:none: {css.get('pointer_events_none_count', 0)}")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Auditoría estática preliminar de un HTML del POS Nuevo Amanecer.")
    parser.add_argument("html", type=Path, help="Archivo HTML a analizar.")
    parser.add_argument("--format", choices=("markdown", "json"), default="markdown")
    parser.add_argument("--output", type=Path, help="Guardar el resultado en un archivo.")
    args = parser.parse_args()

    if not args.html.is_file():
        parser.error(f"No existe el archivo: {args.html}")

    findings, summary = audit_html(args.html)
    if args.format == "json":
        result = json.dumps(
            {"summary": summary, "findings": [asdict(item) for item in findings]},
            ensure_ascii=False,
            indent=2,
        ) + "\n"
    else:
        result = render_markdown(findings, summary)

    if args.output:
        args.output.write_text(result, encoding="utf-8")
    else:
        sys.stdout.write(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
