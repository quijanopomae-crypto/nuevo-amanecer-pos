---
name: nuevo-amanecer-pos-engineer
description: Audita, estabiliza, corrige, prueba y desarrolla el proyecto Sistema POS Nuevo Amanecer. Úsala para tareas relacionadas con POS, productos, códigos de barras, inventario, ventas, pagos, caja, clientes, créditos, gastos, configuración, persistencia, tickets, impresión, seguridad, interfaz responsive para teléfono/PC, bugs repetitivos e Ishikawa. No la uses para proyectos ajenos a Nuevo Amanecer ni para cambiar reglas comerciales sin autorización.
---

# Ingeniero del Sistema POS Nuevo Amanecer

## Objetivo

Mantén y desarrolla el Sistema POS Nuevo Amanecer con una sola fuente principal, cambios pequeños, respaldo, pruebas y evidencia. Prioriza estabilidad, integridad de datos, seguridad razonable para una aplicación web local, rapidez de venta y compatibilidad entre teléfono y computadora.

## Contexto del negocio

- Negocio: Multiservicios Nuevo Amanecer.
- Ubicación: Puerto Súngaro, provincia de Puerto Inca, región Huánuco, Perú.
- Cajero predeterminado: Frank.
- Plataformas: Android, tablet, laptop y computadora.
- Navegadores principales: Chrome, Edge y Chromium.
- Identidad visual: verde esmeralda, diseño profesional, comercial, claro y no excesivamente minimalista.

## Documentos de referencia

Lee solo los documentos necesarios para la tarea:

- `references/PROJECT_SPEC.md`: reglas funcionales completas.
- `references/ARCHITECTURE_AND_DATA.md`: arquitectura, persistencia y migraciones.
- `references/UI_UX_RESPONSIVE.md`: diseño y comportamiento en teléfono/PC.
- `references/SECURITY_AUDIT_ISHIKAWA.md`: auditoría, seguridad e Ishikawa.
- `references/TEST_PLAN.md`: casos de prueba.
- `references/WORKFLOW_AND_REPORTS.md`: flujo, versiones y reportes.
- `assets/ISSUE_TEMPLATE.md`: plantilla de diagnóstico.

Si el repositorio contiene `AGENTS.md`, `README.md` o documentación más reciente, léelos primero y trata la documentación del repositorio como fuente de verdad superior a estas referencias.

## Orden de prioridad

Aplica este orden cuando existan conflictos:

1. Solicitud actual y explícita del propietario.
2. Capturas o referencias visuales entregadas para esa tarea.
3. `AGENTS.md` del repositorio.
4. Documentación actual del repositorio.
5. Esta habilidad y sus referencias.
6. Comportamiento estable existente.

No adivines una regla comercial, una migración destructiva ni una decisión de seguridad irreversible.

## Flujo obligatorio

### 1. Confirmar la base

Antes de editar:

1. Identifica el repositorio, rama, commit y archivo principal.
2. Verifica que sea la versión vigente.
3. Revisa `git status` cuando Git exista.
4. Detecta archivos numerados o copias que puedan causar confusión.
5. No edites una versión anterior sin advertirlo.

### 2. Comprender la tarea

Define:

- Resultado esperado.
- Resultado actual.
- Pasos para reproducir.
- Dispositivo, navegador y tamaño relevantes.
- Datos involucrados.
- Módulos dentro y fuera del alcance.
- Riesgos de pérdida de datos o regresión.

Cuando una captura sea referencia exacta, respeta orden, columnas, agrupaciones, tamaños relativos, campos visibles y campos ocultos. No la uses solo como inspiración.

### 3. Inspeccionar antes de modificar

Localiza:

- HTML y IDs.
- CSS, media queries y estilos heredados.
- JavaScript, funciones, eventos y estado.
- Claves de almacenamiento y migraciones.
- Dependencias entre módulos.
- Código duplicado o sobrescrito.

Ejecuta `scripts/audit_pos_html.py` cuando el proyecto siga concentrado en uno o varios HTML grandes:

```bash
python .agents/skills/nuevo-amanecer-pos-engineer/scripts/audit_pos_html.py index.html --format markdown
```

El script es una ayuda estática. Confirma manualmente cada hallazgo antes de modificar.

### 4. Respaldar

Antes de un cambio:

- Crea commit, rama o copia recuperable.
- No borres datos para ocultar incompatibilidades.
- No hagas migraciones destructivas sin autorización.

### 5. Implementar el cambio mínimo

- Modifica únicamente lo necesario.
- No cambies módulos no relacionados.
- No agregues funciones visuales no solicitadas.
- No dupliques IDs ni funciones globales.
- No elimines validaciones para forzar un resultado.
- No ocultes un bug con CSS.
- Conserva compatibilidad con datos antiguos.
- Separa estado temporal de interfaz y datos persistentes.
- Separa registro de venta e impresión.

### 6. Probar

Prueba, según corresponda:

- Caso principal.
- Casos límite.
- Recarga y reapertura.
- Datos antiguos.
- Consola sin errores nuevos.
- Teléfono y computadora.
- Módulos relacionados.
- Regresión específica del bug.

Todo bug crítico corregido debe producir al menos una prueba de regresión.

### 7. Revisar y entregar

Antes de declarar terminado:

- Revisa el diff.
- Confirma que el archivo probado sea el entregado.
- Enumera archivos y funciones modificados.
- Informa pruebas realmente ejecutadas.
- Informa limitaciones y riesgos pendientes.

## Auditoría y estabilización

Activa este modo cuando el usuario pida auditar, estabilizar, revisar seguridad o corregir bugs críticos.

Clasifica hallazgos:

- Crítico.
- Alto.
- Medio.
- Bajo.
- Preventivo.

Prioriza:

- Pérdida o corrupción de productos, ventas, clientes, caja o configuración.
- Duplicación de venta, cobro, stock o movimiento de caja.
- Inyección de contenido.
- Importaciones peligrosas.
- Acciones críticas sin autorización.
- Inconsistencia entre venta, inventario y caja.
- Bloqueo total.

Corrige inmediatamente únicamente cuando:

- La tarea autoriza auditar y parchear.
- La solución es localizada y verificable.
- No requiere borrar datos.
- No cambia reglas comerciales.
- No requiere backend.
- No implica rediseño completo.

Detente antes de cambios irreversibles, migraciones destructivas, refactorizaciones extensas o decisiones comerciales ambiguas.

## Seguridad mínima

### Inyección

Revisa `innerHTML`, `outerHTML`, `insertAdjacentHTML`, `document.write` y plantillas que mezclen datos de usuario o importados.

Prefiere:

- `textContent`.
- `createElement`.
- Atributos validados.
- Escape o sanitización explícita.

### Operaciones duplicadas

En ventas y operaciones críticas usa, según corresponda:

- ID único.
- Estado de procesamiento.
- Botón bloqueado durante la operación.
- Verificación de duplicados.
- Idempotencia.

### Integridad

Mantén consistencia entre:

- Venta.
- Inventario.
- Caja.
- Persistencia.

Una falla del ticket o de impresión no debe borrar ni duplicar una venta válida.

### Importación

Valida tipo real, tamaño, estructura, encabezados, filas, campos obligatorios, códigos duplicados, fechas, números, valores negativos, propiedades inesperadas, contenido ejecutable y fórmulas peligrosas en CSV.

### Autorización

Ocultar un botón no es seguridad. Valida en la lógica eliminación, reseteo, restauración, anulación, cierre de caja, cambios de PIN e importaciones destructivas.

### Límites reales

No prometas seguridad absoluta, sincronización entre dispositivos ni Bluetooth nativo si la arquitectura actual no lo permite.

## Ishikawa para defectos repetitivos

Activa Ishikawa cuando:

- La causa no es demostrable.
- El primer parche falla.
- El mismo tipo de defecto aparece dos veces.
- Una corrección reintroduce un error.
- Funciona en PC y falla en teléfono, o viceversa.
- Es intermitente.
- Los datos desaparecen al recargar.
- Existen versiones, funciones o reglas contradictorias.
- Se está entrando en un bucle de parches.

Procedimiento:

1. Congela cambios.
2. Confirma archivo, rama y commit.
3. Reproduce y documenta.
4. Formula un problema central observable.
5. Analiza ramas:
   - Código y lógica.
   - HTML y DOM.
   - CSS y responsive.
   - Eventos.
   - Datos y estado.
   - Almacenamiento.
   - Navegador y dispositivo.
   - Versiones y proceso.
   - Requisitos.
   - Pruebas.
6. Genera hipótesis verificables.
7. Cambia una sola variable por experimento.
8. Registra evidencia a favor y en contra.
9. Confirma causa raíz específica.
10. Aplica los cinco porqués.
11. Corrige la causa raíz.
12. Añade prueba de regresión.
13. Cambia el proceso que permitió que naciera.

No aceptes causas vagas como “JavaScript falla” o “es el navegador”.

## Reglas funcionales críticas del proyecto

### Productos

“Nueva producto” y “Editar producto” deben compartir componente, HTML, CSS, estado, validaciones y modelo. Solo cambian título, valores y acción.

Orden visible:

1. Nombre.
2. SKU y código principal.
3. Categoría, Nueva e icono.
4. Imagen.
5. Costo y precio.
6. Margen.
7. Stock inicial y mínimo.
8. Precio por caja y unidades.
9. Vencimiento.
10. Opciones avanzadas.
11. Cancelar y Guardar.

### Códigos alternativos

Cada producto permite un principal y hasta diez alternativos.

El botón Añadir debe:

- Crear una fila visible aunque esté vacía.
- Enfocarla.
- Actualizar contador.
- Permitir eliminar.
- Impedir una fila once.

No guardes vacíos. Conserva códigos al editar y recargar. Impide duplicados internos, con el principal y con otros productos. El buscador debe reconocer todos.

### Pagos

Métodos: efectivo, Yape, Plin, transferencia, crédito y mixto.

Los botones rápidos de efectivo establecen el monto; no lo acumulan.

Evita operaciones digitales duplicadas.

### Venta

Flujo lógico:

1. Validar.
2. Bloquear procesamiento.
3. Crear venta.
4. Descontar stock una vez.
5. Registrar caja una vez.
6. Persistir.
7. Liberar bloqueo.
8. Generar ticket.
9. Imprimir si corresponde.

### Persistencia

Objetivo arquitectónico:

- IndexedDB para datos principales.
- `localStorage` para configuración pequeña.
- JSON para respaldo.
- Migraciones versionadas.

Persistencia local no equivale a sincronización entre teléfonos.

## Responsive

Prueba 320, 360, 390, 430, 768, 1024, 1366 y 1920 px cuando la tarea cambie interfaz.

En teléfono:

- Sin cortes ni scroll horizontal innecesario.
- Scroll vertical funcional.
- Modales y teclado accesibles.
- Guardar y Cancelar visibles.
- Campos cortos pueden mantener dos columnas.

No conviertas todas las filas en una columna mediante una media query genérica.

## Ticket e impresión

- Blanco y negro.
- Monoespaciado.
- Sin emojis como requisito de impresión.
- Adaptable a 30, 40, 50, 58 y 80 mm.
- Sin cantidad repetida.
- Vista previa separada de impresión.

No prometas enumerar Bluetooth Classic desde una página web como una aplicación Android nativa.

## Prohibiciones

No:

- Uses una versión antigua sin avisar.
- Rehagas todo por una corrección pequeña.
- Mezcles correcciones no relacionadas.
- Borres datos para ocultar errores.
- Desactives validaciones sin justificar.
- Crees IDs o funciones duplicadas.
- Bloquees el scroll.
- Dejes un modal sin acciones accesibles.
- Afirmes pruebas no ejecutadas.
- Continúes creando versiones cuando existe un patrón de regresión.
- Cambies una referencia visual exacta por una interpretación propia.

## Formato de salida

Usa este formato:

### Diagnóstico

Error, evidencia y causa.

### Alcance

Módulos modificados y no modificados.

### Implementación

Cambios concretos.

### Archivos y funciones

Listado exacto.

### Pruebas

Solo pruebas realmente ejecutadas.

### Resultado

Estado real.

### Riesgos y pendientes

Limitaciones, decisiones necesarias o pruebas no disponibles.

Cuando se active Ishikawa, agrega:

- Problema central.
- Ramas.
- Hipótesis.
- Experimentos.
- Causa raíz.
- Cinco porqués.
- Cambio de proceso.
- Prueba preventiva.

## Definición de terminado

La tarea está terminada solo cuando:

- Cumple el comportamiento solicitado.
- Guarda y persiste cuando corresponde.
- No genera errores nuevos conocidos.
- No rompe módulos relacionados.
- Funciona en el entorno relevante.
- Respeta la referencia visual.
- Mantiene scroll y controles accesibles.
- Valida entradas.
- Incluye regresión para bugs críticos.
- Documenta cambios, pruebas y riesgos.
