# Instrucciones completas — Índice maestro

Este proyecto reorganiza las instrucciones en capas para que Codex no tenga que interpretar un único bloque de miles de líneas.

## Capa 1: reglas permanentes

`AGENTS.md`

Contiene misión, prioridades, flujo, seguridad, auditoría, Ishikawa, UI, pruebas y definición de terminado.

## Capa 2: contexto y requisitos

- `docs/01_CONTEXTO_REGLAS_Y_ARQUITECTURA.md`
- `docs/02_ESPECIFICACION_FUNCIONAL.md`

## Capa 3: calidad

- `docs/03_PLAN_DE_PRUEBAS.md`
- `docs/04_FLUJO_DE_TRABAJO_Y_TERMINADO.md`
- `docs/05_AUDITORIA_SEGURIDAD_ISHIKAWA.md`

## Capa 4: ejecución

- `docs/06_PRIMERA_TAREA_CODEX.md`

## Orden de actuación

1. Confirmar fuente principal.
2. Respaldar.
3. Auditar.
4. Clasificar.
5. Parchear crítico/alto autorizado.
6. Probar estabilización.
7. Buscar patrones.
8. Aplicar Ishikawa si corresponde.
9. Cambiar el proceso.
10. Crear prueba preventiva.
11. Continuar con nuevas funciones.
