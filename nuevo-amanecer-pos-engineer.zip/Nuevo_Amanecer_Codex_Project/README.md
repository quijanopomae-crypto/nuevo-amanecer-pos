# Sistema POS Nuevo Amanecer — Proyecto para ChatGPT Codex

## Propósito

Repositorio principal del Sistema POS de Multiservicios Nuevo Amanecer. Reúne el código, reglas funcionales, guía responsive, auditoría, seguridad, Ishikawa, pruebas y flujo de control de versiones.

## Cómo usarlo con Codex

1. Coloca dentro de esta carpeta el último archivo estable del POS.
2. Conserva una copia del archivo original.
3. Inicializa Git y crea el primer commit estable.
4. Abre la carpeta completa como proyecto en Codex.
5. Pide a Codex que lea `AGENTS.md` y `docs/06_PRIMERA_TAREA_CODEX.md`.
6. Trabaja mediante commits; no mediante una cadena de HTML numerados.

## Organización

- `AGENTS.md`: reglas operativas que Codex debe aplicar siempre.
- `docs/01_CONTEXTO_REGLAS_Y_ARQUITECTURA.md`: identidad, propósito, arquitectura, reglas, versiones, responsive e identidad visual.
- `docs/02_ESPECIFICACION_FUNCIONAL.md`: módulos y comportamiento del sistema.
- `docs/03_PLAN_DE_PRUEBAS.md`: pruebas obligatorias.
- `docs/04_FLUJO_DE_TRABAJO_Y_TERMINADO.md`: proceso, prohibiciones, definición de terminado y formato de informes.
- `docs/05_AUDITORIA_SEGURIDAD_ISHIKAWA.md`: auditoría, exploits, parches críticos, Ishikawa y prevención.
- `docs/06_PRIMERA_TAREA_CODEX.md`: prompt inicial listo para usar.
- `INSTRUCCIONES_COMPLETAS_CODEX.md`: índice maestro de toda la documentación.

## Estado técnico inicial

El sistema puede comenzar como una aplicación web contenida en un HTML grande. La separación en módulos debe realizarse gradualmente después de auditar dependencias, crear respaldo y agregar pruebas.

## Comandos del proyecto

Codex debe completar esta sección después de inspeccionar el repositorio. No debe inventar scripts.

### Ejecutar

```text
PENDIENTE DE DESCUBRIR EN EL REPOSITORIO
```

### Probar

```text
PENDIENTE DE DESCUBRIR EN EL REPOSITORIO
```

## Principio central

**Auditoría → parche crítico → estabilización → Ishikawa → cambio del proceso → prueba preventiva.**
