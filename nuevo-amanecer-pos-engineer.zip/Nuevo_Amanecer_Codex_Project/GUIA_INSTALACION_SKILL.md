# Guía de instalación — Skill Nuevo Amanecer

## Opción 1: dentro del repositorio de Codex

1. Descomprime `Nuevo_Amanecer_POS_Skill_Codex.zip`.
2. Copia la carpeta `nuevo-amanecer-pos-engineer` a:

```text
<raíz-del-proyecto>/.agents/skills/nuevo-amanecer-pos-engineer/
```

3. Abre la raíz del proyecto en Codex.
4. Usa `/skills` o escribe `$nuevo-amanecer-pos-engineer`.
5. Si no aparece, reinicia Codex.

## Opción 2: paquete ya integrado

Descomprime `Nuevo_Amanecer_Codex_Project_con_Skill.zip`. La habilidad ya estará dentro de:

```text
Nuevo_Amanecer_Codex_Project/.agents/skills/nuevo-amanecer-pos-engineer/
```

Coloca el archivo principal del POS en la raíz del proyecto y abre esa carpeta en Codex.

## Primera orden sugerida

```text
Usa $nuevo-amanecer-pos-engineer.
Lee AGENTS.md y la documentación del proyecto. Confirma el archivo principal,
crea un respaldo, ejecuta la auditoría, clasifica los hallazgos y corrige solo
los problemas críticos y altos que puedan resolverse sin borrar datos ni cambiar
reglas comerciales. Prueba las correcciones y aplica Ishikawa cuando detectes un
patrón repetitivo o una causa no demostrada.
```

## Auditoría estática auxiliar

Desde la raíz del proyecto:

```bash
python .agents/skills/nuevo-amanecer-pos-engineer/scripts/audit_pos_html.py index.html --format markdown --output auditoria.md
```

El informe es preliminar. Los hallazgos deben confirmarse mediante revisión y pruebas en navegador.
