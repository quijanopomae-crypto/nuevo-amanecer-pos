# Changelog

## Línea base pendiente

- Registrar el primer commit estable.
- Ejecutar la auditoría inicial.
- Documentar parches y pruebas.
